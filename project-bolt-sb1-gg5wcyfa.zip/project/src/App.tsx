import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import BotConfig from './components/BotConfig';
import MessengerSimulator from './components/MessengerSimulator';
import Analytics from './components/Analytics';
import Conversations from './components/Conversations';
import FacebookIntegration from './components/FacebookIntegration';
import NLPManagement from './components/NLPManagement';
import MultiPageManagement from './components/MultiPageManagement';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'conversations':
        return <Conversations />;
      case 'bot-config':
        return <BotConfig />;
      case 'facebook-integration':
        return <FacebookIntegration />;
      case 'nlp-management':
        return <NLPManagement />;
      case 'multi-pages':
        return <MultiPageManagement />;
      case 'analytics':
        return <Analytics />;
      case 'schedule':
        return <MessengerSimulator />;
      case 'customers':
        return <MessengerSimulator />;
      case 'settings':
        return <BotConfig />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 overflow-auto">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;