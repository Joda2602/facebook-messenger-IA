import React, { useState, useEffect } from 'react';
import { Facebook, Plus, Settings, BarChart3, MessageCircle, CheckCircle, AlertCircle } from 'lucide-react';

interface FacebookPage {
  _id: string;
  pageId: string;
  pageName: string;
  isActive: boolean;
  webhookVerified: boolean;
  analytics: {
    totalMessages: number;
    totalConversations: number;
    averageResponseTime: number;
    satisfactionRate: number;
  };
  settings: {
    greetingText: string;
    persistentMenu: Array<{
      type: string;
      title: string;
      url?: string;
      payload?: string;
    }>;
  };
  createdAt: string;
}

const MultiPageManagement: React.FC = () => {
  const [pages, setPages] = useState<FacebookPage[]>([]);
  const [selectedPage, setSelectedPage] = useState<FacebookPage | null>(null);
  const [isAddingPage, setIsAddingPage] = useState(false);
  const [newPageData, setNewPageData] = useState({
    pageId: '',
    accessToken: '',
    greetingText: 'Bonjour ! Je suis votre assistant virtuel.'
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadPages();
  }, []);

  const loadPages = async () => {
    try {
      const response = await fetch('/api/pages');
      const data = await response.json();
      if (data.success) {
        setPages(data.data);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des pages:', error);
    }
  };

  const addPage = async () => {
    if (!newPageData.pageId || !newPageData.accessToken) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/pages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pageId: newPageData.pageId,
          accessToken: newPageData.accessToken,
          settings: {
            greetingText: newPageData.greetingText
          }
        })
      });
      
      const data = await response.json();
      if (data.success) {
        await loadPages();
        setIsAddingPage(false);
        setNewPageData({
          pageId: '',
          accessToken: '',
          greetingText: 'Bonjour ! Je suis votre assistant virtuel.'
        });
      } else {
        alert('Erreur lors de l\'ajout de la page: ' + data.error?.message);
      }
    } catch (error) {
      console.error('Erreur lors de l\'ajout:', error);
      alert('Erreur lors de l\'ajout de la page');
    } finally {
      setIsLoading(false);
    }
  };

  const updatePageSettings = async (pageId: string, settings: any) => {
    try {
      const response = await fetch(`/api/pages/${pageId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings })
      });
      
      const data = await response.json();
      if (data.success) {
        await loadPages();
        alert('Paramètres mis à jour avec succès');
      }
    } catch (error) {
      console.error('Erreur lors de la mise à jour:', error);
      alert('Erreur lors de la mise à jour');
    }
  };

  const removePage = async (pageId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette page ?')) return;
    
    try {
      const response = await fetch(`/api/pages/${pageId}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      if (data.success) {
        await loadPages();
        setSelectedPage(null);
      }
    } catch (error) {
      console.error('Erreur lors de la suppression:', error);
    }
  };

  const getStatusIcon = (page: FacebookPage) => {
    if (!page.isActive) {
      return <AlertCircle className="w-5 h-5 text-red-500" />;
    }
    if (!page.webhookVerified) {
      return <AlertCircle className="w-5 h-5 text-yellow-500" />;
    }
    return <CheckCircle className="w-5 h-5 text-green-500" />;
  };

  const getStatusText = (page: FacebookPage) => {
    if (!page.isActive) return 'Inactif';
    if (!page.webhookVerified) return 'Webhook non vérifié';
    return 'Actif';
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Gestion Multi-Pages</h1>
          <p className="text-gray-600 mt-2">Gérez plusieurs pages Facebook depuis une seule interface</p>
        </div>
        <button
          onClick={() => setIsAddingPage(true)}
          className="bg-blue-500 text-white px-6 py-3 rounded-lg flex items-center space-x-2 hover:bg-blue-600 transition-colors duration-200"
        >
          <Plus className="w-5 h-5" />
          <span>Ajouter une page</span>
        </button>
      </div>

      {/* Modal d'ajout de page */}
      {isAddingPage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Ajouter une nouvelle page</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Page ID Facebook</label>
                <input
                  type="text"
                  value={newPageData.pageId}
                  onChange={(e) => setNewPageData({...newPageData, pageId: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="ID de votre page Facebook"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Page Access Token</label>
                <input
                  type="password"
                  value={newPageData.accessToken}
                  onChange={(e) => setNewPageData({...newPageData, accessToken: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Token d'accès de la page"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message de bienvenue</label>
                <textarea
                  value={newPageData.greetingText}
                  onChange={(e) => setNewPageData({...newPageData, greetingText: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={3}
                />
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button
                onClick={addPage}
                disabled={isLoading}
                className="flex-1 bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors duration-200 disabled:opacity-50"
              >
                {isLoading ? 'Ajout en cours...' : 'Ajouter'}
              </button>
              <button
                onClick={() => setIsAddingPage(false)}
                className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600 transition-colors duration-200"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Liste des pages */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-md border border-gray-100">
            <div className="p-4 border-b border-gray-200">
              <h3 className="text-lg font-bold text-gray-800">Pages Facebook ({pages.length})</h3>
            </div>
            
            <div className="max-h-96 overflow-y-auto">
              {pages.map(page => (
                <div
                  key={page._id}
                  onClick={() => setSelectedPage(page)}
                  className={`p-4 border-b border-gray-100 cursor-pointer transition-colors duration-200 hover:bg-gray-50 ${
                    selectedPage?._id === page._id ? 'bg-blue-50 border-blue-200' : ''
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                        <Facebook className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-800">{page.pageName}</h4>
                        <p className="text-sm text-gray-600">{page.pageId}</p>
                      </div>
                    </div>
                    {getStatusIcon(page)}
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      page.isActive && page.webhookVerified
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {getStatusText(page)}
                    </span>
                    <span className="text-gray-500">
                      {page.analytics.totalMessages} messages
                    </span>
                  </div>
                </div>
              ))}
              
              {pages.length === 0 && (
                <div className="p-8 text-center">
                  <Facebook className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Aucune page configurée</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Détails de la page */}
        <div className="lg:col-span-2">
          {selectedPage ? (
            <div className="space-y-6">
              {/* En-tête */}
              <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-blue-500 rounded-xl flex items-center justify-center">
                      <Facebook className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-800">{selectedPage.pageName}</h3>
                      <p className="text-gray-600">ID: {selectedPage.pageId}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        {getStatusIcon(selectedPage)}
                        <span className="text-sm text-gray-600">{getStatusText(selectedPage)}</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => removePage(selectedPage.pageId)}
                    className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors duration-200"
                  >
                    Supprimer
                  </button>
                </div>
              </div>

              {/* Statistiques */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Messages', value: selectedPage.analytics.totalMessages, icon: MessageCircle, color: 'bg-blue-500' },
                  { label: 'Conversations', value: selectedPage.analytics.totalConversations, icon: MessageCircle, color: 'bg-green-500' },
                  { label: 'Temps réponse', value: `${selectedPage.analytics.averageResponseTime.toFixed(1)}s`, icon: BarChart3, color: 'bg-orange-500' },
                  { label: 'Satisfaction', value: `${selectedPage.analytics.satisfactionRate}%`, icon: CheckCircle, color: 'bg-purple-500' }
                ].map((stat, index) => {
                  const Icon = stat.icon;
                  return (
                    <div key={index} className="bg-white p-4 rounded-xl shadow-md border border-gray-100">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600">{stat.label}</p>
                          <p className="text-xl font-bold text-gray-800">{stat.value}</p>
                        </div>
                        <div className={`p-2 rounded-lg ${stat.color}`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Paramètres */}
              <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
                <div className="flex items-center space-x-3 mb-6">
                  <Settings className="w-6 h-6 text-blue-500" />
                  <h3 className="text-lg font-bold text-gray-800">Paramètres de la page</h3>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Message de bienvenue</label>
                    <textarea
                      value={selectedPage.settings.greetingText}
                      onChange={(e) => {
                        const updatedPage = {
                          ...selectedPage,
                          settings: {
                            ...selectedPage.settings,
                            greetingText: e.target.value
                          }
                        };
                        setSelectedPage(updatedPage);
                      }}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      rows={3}
                    />
                  </div>
                  
                  <button
                    onClick={() => updatePageSettings(selectedPage.pageId, selectedPage.settings)}
                    className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors duration-200"
                  >
                    Sauvegarder les paramètres
                  </button>
                </div>
              </div>

              {/* Instructions */}
              <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">Configuration du webhook</h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-700 mb-2">
                    <strong>URL du webhook:</strong> {window.location.origin}/webhook
                  </p>
                  <p className="text-sm text-gray-700 mb-2">
                    <strong>Token de vérification:</strong> {process.env.FACEBOOK_VERIFY_TOKEN || 'Configurez FACEBOOK_VERIFY_TOKEN'}
                  </p>
                  <p className="text-sm text-gray-600">
                    Configurez ces paramètres dans les paramètres Messenger de votre application Facebook.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-md border border-gray-100 h-full flex items-center justify-center">
              <div className="text-center">
                <Facebook className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-600 mb-2">Sélectionnez une page</h3>
                <p className="text-gray-500">Choisissez une page pour voir les détails et la configurer</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MultiPageManagement;