import React, { useState } from 'react';
import { Bot, Save, Plus, Trash2 } from 'lucide-react';

const BotConfig: React.FC = () => {
  const [botName, setBotName] = useState('Assistant virtuel');
  const [botPersonality, setBotPersonality] = useState('Amical et professionnel');
  const [responses, setResponses] = useState([
    { id: 1, trigger: 'bonjour', response: 'Bonjour ! Comment puis-je vous aider aujourd\'hui ?' },
    { id: 2, trigger: 'prix', response: 'Je vais vous mettre en relation avec un conseiller pour discuter des tarifs.' },
    { id: 3, trigger: 'horaires', response: 'Nous sommes ouverts du lundi au vendredi de 9h à 18h.' }
  ]);

  const addResponse = () => {
    const newId = Math.max(...responses.map(r => r.id)) + 1;
    setResponses([...responses, { id: newId, trigger: '', response: '' }]);
  };

  const removeResponse = (id: number) => {
    setResponses(responses.filter(r => r.id !== id));
  };

  const updateResponse = (id: number, field: 'trigger' | 'response', value: string) => {
    setResponses(responses.map(r => 
      r.id === id ? { ...r, [field]: value } : r
    ));
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Configuration du Bot</h1>
          <p className="text-gray-600 mt-2">Personnalisez votre assistant AI</p>
        </div>
        <button className="bg-blue-500 text-white px-6 py-3 rounded-lg flex items-center space-x-2 hover:bg-blue-600 transition-colors duration-200">
          <Save className="w-5 h-5" />
          <span>Sauvegarder</span>
        </button>
      </div>

      {/* Bot Identity */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <Bot className="w-6 h-6 text-blue-500" />
          <h2 className="text-xl font-bold text-gray-800">Identité du Bot</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Nom du Bot</label>
            <input
              type="text"
              value={botName}
              onChange={(e) => setBotName(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              placeholder="Nom de votre assistant"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Personnalité</label>
            <select
              value={botPersonality}
              onChange={(e) => setBotPersonality(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            >
              <option value="Amical et professionnel">Amical et professionnel</option>
              <option value="Formel et concis">Formel et concis</option>
              <option value="Décontracté et fun">Décontracté et fun</option>
              <option value="Technique et précis">Technique et précis</option>
            </select>
          </div>
        </div>
      </div>

      {/* Automated Responses */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-800">Réponses Automatiques</h2>
          <button
            onClick={addResponse}
            className="bg-green-500 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-green-600 transition-colors duration-200"
          >
            <Plus className="w-4 h-4" />
            <span>Ajouter</span>
          </button>
        </div>

        <div className="space-y-4">
          {responses.map((response) => (
            <div key={response.id} className="p-4 border border-gray-200 rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Mot-clé déclencheur</label>
                  <input
                    type="text"
                    value={response.trigger}
                    onChange={(e) => updateResponse(response.id, 'trigger', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Ex: bonjour, prix, horaires..."
                  />
                </div>
                
                <div className="flex space-x-2">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Réponse</label>
                    <input
                      type="text"
                      value={response.response}
                      onChange={(e) => updateResponse(response.id, 'response', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Réponse du bot..."
                    />
                  </div>
                  <div className="flex items-end">
                    <button
                      onClick={() => removeResponse(response.id)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-md transition-colors duration-200"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Advanced Settings */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-6">Paramètres Avancés</h2>
        
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-gray-800">Réponse automatique</h3>
              <p className="text-sm text-gray-600">Activer les réponses automatiques</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" defaultChecked className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-gray-800">Transfert vers humain</h3>
              <p className="text-sm text-gray-600">Transférer les demandes complexes</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" defaultChecked className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BotConfig;