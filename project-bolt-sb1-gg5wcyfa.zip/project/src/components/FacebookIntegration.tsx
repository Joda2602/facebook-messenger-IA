import React, { useState, useEffect } from 'react';
import { Facebook, CheckCircle, AlertCircle, Settings, Key, Webhook } from 'lucide-react';

const FacebookIntegration: React.FC = () => {
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'error'>('disconnected');
  const [config, setConfig] = useState({
    appId: '',
    pageAccessToken: '',
    verifyToken: '',
    webhookUrl: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [testMessage, setTestMessage] = useState('');
  const [testResponse, setTestResponse] = useState('');

  useEffect(() => {
    checkConnectionStatus();
  }, []);

  const checkConnectionStatus = async () => {
    try {
      const response = await fetch('/api/health');
      if (response.ok) {
        setConnectionStatus('connected');
      } else {
        setConnectionStatus('error');
      }
    } catch (error) {
      setConnectionStatus('disconnected');
    }
  };

  const testAI = async () => {
    if (!testMessage.trim()) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: testMessage })
      });
      
      const data = await response.json();
      setTestResponse(data.response);
    } catch (error) {
      setTestResponse('Erreur lors du test de l\'IA');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = () => {
    switch (connectionStatus) {
      case 'connected':
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'error':
        return <AlertCircle className="w-6 h-6 text-red-500" />;
      default:
        return <AlertCircle className="w-6 h-6 text-yellow-500" />;
    }
  };

  const getStatusText = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'Connecté et opérationnel';
      case 'error':
        return 'Erreur de connexion';
      default:
        return 'Non connecté';
    }
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Intégration Facebook</h1>
        <p className="text-gray-600 mt-2">Configurez votre bot pour Facebook Messenger</p>
      </div>

      {/* Status Card */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
              <Facebook className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-800">Statut de la connexion</h3>
              <p className="text-gray-600">{getStatusText()}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            <button
              onClick={checkConnectionStatus}
              className="text-blue-500 hover:text-blue-600 font-medium"
            >
              Vérifier
            </button>
          </div>
        </div>
      </div>

      {/* Configuration */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <Settings className="w-6 h-6 text-blue-500" />
          <h2 className="text-xl font-bold text-gray-800">Configuration</h2>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Key className="w-4 h-4 inline mr-2" />
                App ID Facebook
              </label>
              <input
                type="text"
                value={config.appId}
                onChange={(e) => setConfig({...config, appId: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Votre Facebook App ID"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Key className="w-4 h-4 inline mr-2" />
                Page Access Token
              </label>
              <input
                type="password"
                value={config.pageAccessToken}
                onChange={(e) => setConfig({...config, pageAccessToken: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Votre Page Access Token"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Key className="w-4 h-4 inline mr-2" />
                Verify Token
              </label>
              <input
                type="text"
                value={config.verifyToken}
                onChange={(e) => setConfig({...config, verifyToken: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Votre token de vérification"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Webhook className="w-4 h-4 inline mr-2" />
                Webhook URL
              </label>
              <input
                type="url"
                value={config.webhookUrl}
                onChange={(e) => setConfig({...config, webhookUrl: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="https://votre-domaine.com/webhook"
              />
            </div>
          </div>

          <button className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors duration-200">
            Sauvegarder la configuration
          </button>
        </div>
      </div>

      {/* Instructions */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-6">Instructions de configuration</h2>
        
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
            <div>
              <h3 className="font-medium text-gray-800">Créer une application Facebook</h3>
              <p className="text-gray-600 text-sm">Rendez-vous sur <a href="https://developers.facebook.com" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">Facebook Developers</a> et créez une nouvelle application.</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
            <div>
              <h3 className="font-medium text-gray-800">Configurer Messenger</h3>
              <p className="text-gray-600 text-sm">Ajoutez le produit "Messenger" à votre application et générez un Page Access Token.</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
            <div>
              <h3 className="font-medium text-gray-800">Configurer le Webhook</h3>
              <p className="text-gray-600 text-sm">Ajoutez l'URL de votre webhook et le token de vérification dans les paramètres Messenger.</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
            <div>
              <h3 className="font-medium text-gray-800">Tester l'intégration</h3>
              <p className="text-gray-600 text-sm">Envoyez un message à votre page Facebook pour tester le bot.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Test AI */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-6">Tester l'IA</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Message de test</label>
            <input
              type="text"
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Tapez un message pour tester l'IA..."
              onKeyPress={(e) => e.key === 'Enter' && testAI()}
            />
          </div>

          <button
            onClick={testAI}
            disabled={isLoading || !testMessage.trim()}
            className="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Test en cours...' : 'Tester l\'IA'}
          </button>

          {testResponse && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium text-gray-800 mb-2">Réponse de l'IA:</h4>
              <p className="text-gray-700">{testResponse}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FacebookIntegration;