import React from 'react';
import { TrendingUp, MessageCircle, Clock, Users, Star } from 'lucide-react';

const Analytics: React.FC = () => {
  const metrics = [
    { title: 'Messages Traités', value: '1,247', change: '+23%', icon: MessageCircle },
    { title: 'Temps Réponse Moyen', value: '1.8s', change: '-12%', icon: Clock },
    { title: 'Clients Satisfaits', value: '96%', change: '+2%', icon: Star },
    { title: 'Taux de Résolution', value: '87%', change: '+5%', icon: TrendingUp }
  ];

  const weeklyData = [
    { day: 'Lun', messages: 45, satisfaction: 94 },
    { day: 'Mar', messages: 52, satisfaction: 96 },
    { day: 'Mer', messages: 38, satisfaction: 95 },
    { day: 'Jeu', messages: 61, satisfaction: 97 },
    { day: 'Ven', messages: 73, satisfaction: 93 },
    { day: 'Sam', messages: 29, satisfaction: 98 },
    { day: 'Dim', messages: 15, satisfaction: 99 }
  ];

  const popularKeywords = [
    { keyword: 'prix', count: 89, percentage: 32 },
    { keyword: 'horaires', count: 67, percentage: 24 },
    { keyword: 'commande', count: 45, percentage: 16 },
    { keyword: 'support', count: 38, percentage: 14 },
    { keyword: 'livraison', count: 34, percentage: 12 }
  ];

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Analytics</h1>
        <p className="text-gray-600 mt-2">Analysez les performances de votre assistant AI</p>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow duration-200">
              <div className="flex items-center justify-between mb-4">
                <Icon className="w-8 h-8 text-blue-500" />
                <span className={`text-sm font-medium px-2 py-1 rounded-full ${
                  metric.change.startsWith('+') ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                }`}>
                  {metric.change}
                </span>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-1">{metric.value}</h3>
              <p className="text-gray-600 text-sm">{metric.title}</p>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Weekly Messages Chart */}
        <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 mb-6">Messages par Jour</h3>
          <div className="space-y-4">
            {weeklyData.map((data, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700 w-12">{data.day}</span>
                <div className="flex-1 mx-4">
                  <div className="bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(data.messages / 73) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <span className="text-sm font-medium text-gray-700 w-8">{data.messages}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Satisfaction Chart */}
        <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 mb-6">Satisfaction Client</h3>
          <div className="space-y-4">
            {weeklyData.map((data, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700 w-12">{data.day}</span>
                <div className="flex-1 mx-4">
                  <div className="bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${data.satisfaction}%` }}
                    ></div>
                  </div>
                </div>
                <span className="text-sm font-medium text-gray-700 w-12">{data.satisfaction}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Popular Keywords */}
      <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
        <h3 className="text-lg font-bold text-gray-800 mb-6">Mots-clés Populaires</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {popularKeywords.map((item, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-gray-800">#{item.keyword}</span>
                <span className="text-sm text-gray-600">{item.count} fois</span>
              </div>
              <div className="bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-purple-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${item.percentage}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Response Time Distribution */}
      <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
        <h3 className="text-lg font-bold text-gray-800 mb-6">Distribution des Temps de Réponse</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">67%</div>
            <div className="text-sm text-gray-600">&lt; 2 secondes</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">23%</div>
            <div className="text-sm text-gray-600">2-5 secondes</div>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">8%</div>
            <div className="text-sm text-gray-600">5-10 secondes</div>
          </div>
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-600">2%</div>
            <div className="text-sm text-gray-600">&gt; 10 secondes</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;