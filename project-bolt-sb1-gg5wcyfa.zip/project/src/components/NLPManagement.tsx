import React, { useState, useEffect } from 'react';
import { Brain, Plus, Edit, Trash2, Save, MessageSquare, Target } from 'lucide-react';

interface Intent {
  _id: string;
  name: string;
  displayName: string;
  description: string;
  trainingPhrases: Array<{
    text: string;
    entities: Array<{
      entity: string;
      value: string;
      start: number;
      end: number;
    }>;
  }>;
  responses: Array<{
    text: string;
    quickReplies: string[];
  }>;
  priority: number;
  isActive: boolean;
}

interface Entity {
  _id: string;
  name: string;
  displayName: string;
  entityType: 'system' | 'custom' | 'regexp';
  values: Array<{
    value: string;
    synonyms: string[];
  }>;
  isActive: boolean;
}

const NLPManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'intents' | 'entities' | 'test'>('intents');
  const [intents, setIntents] = useState<Intent[]>([]);
  const [entities, setEntities] = useState<Entity[]>([]);
  const [selectedIntent, setSelectedIntent] = useState<Intent | null>(null);
  const [selectedEntity, setSelectedEntity] = useState<Entity | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [testMessage, setTestMessage] = useState('');
  const [testResult, setTestResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadIntents();
    loadEntities();
  }, []);

  const loadIntents = async () => {
    try {
      const response = await fetch('/api/nlp/intents');
      const data = await response.json();
      if (data.success) {
        setIntents(data.data);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des intents:', error);
    }
  };

  const loadEntities = async () => {
    try {
      const response = await fetch('/api/nlp/entities');
      const data = await response.json();
      if (data.success) {
        setEntities(data.data);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des entités:', error);
    }
  };

  const saveIntent = async (intent: Partial<Intent>) => {
    try {
      const url = intent._id ? `/api/nlp/intents/${intent._id}` : '/api/nlp/intents';
      const method = intent._id ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(intent)
      });
      
      const data = await response.json();
      if (data.success) {
        await loadIntents();
        setSelectedIntent(null);
        setIsEditing(false);
      }
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
    }
  };

  const deleteIntent = async (id: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cet intent ?')) return;
    
    try {
      const response = await fetch(`/api/nlp/intents/${id}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      if (data.success) {
        await loadIntents();
        setSelectedIntent(null);
      }
    } catch (error) {
      console.error('Erreur lors de la suppression:', error);
    }
  };

  const testNLP = async () => {
    if (!testMessage.trim()) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/nlp/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: testMessage })
      });
      
      const data = await response.json();
      if (data.success) {
        setTestResult(data.data);
      }
    } catch (error) {
      console.error('Erreur lors du test:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createNewIntent = () => {
    setSelectedIntent({
      _id: '',
      name: '',
      displayName: '',
      description: '',
      trainingPhrases: [{ text: '', entities: [] }],
      responses: [{ text: '', quickReplies: [] }],
      priority: 0,
      isActive: true
    });
    setIsEditing(true);
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Gestion NLP</h1>
          <p className="text-gray-600 mt-2">Configurez l'intelligence artificielle conversationnelle</p>
        </div>
        <div className="flex items-center space-x-3">
          <Brain className="w-8 h-8 text-blue-500" />
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'intents', label: 'Intentions', icon: Target },
              { id: 'entities', label: 'Entités', icon: MessageSquare },
              { id: 'test', label: 'Test NLP', icon: Brain }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'intents' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Liste des intents */}
              <div className="lg:col-span-1">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-gray-800">Intentions</h3>
                  <button
                    onClick={createNewIntent}
                    className="bg-blue-500 text-white px-3 py-2 rounded-lg flex items-center space-x-2 hover:bg-blue-600 transition-colors duration-200"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Nouveau</span>
                  </button>
                </div>
                
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {intents.map(intent => (
                    <div
                      key={intent._id}
                      onClick={() => setSelectedIntent(intent)}
                      className={`p-3 rounded-lg cursor-pointer transition-colors duration-200 ${
                        selectedIntent?._id === intent._id
                          ? 'bg-blue-50 border-blue-200 border'
                          : 'bg-gray-50 hover:bg-gray-100'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-800">{intent.displayName}</h4>
                          <p className="text-sm text-gray-600">{intent.name}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`w-2 h-2 rounded-full ${
                            intent.isActive ? 'bg-green-400' : 'bg-gray-400'
                          }`}></span>
                          <span className="text-xs text-gray-500">{intent.priority}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Détails de l'intent */}
              <div className="lg:col-span-2">
                {selectedIntent ? (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-gray-800">
                        {isEditing ? 'Modifier l\'intention' : 'Détails de l\'intention'}
                      </h3>
                      <div className="flex space-x-2">
                        {!isEditing ? (
                          <>
                            <button
                              onClick={() => setIsEditing(true)}
                              className="bg-blue-500 text-white px-3 py-2 rounded-lg flex items-center space-x-2 hover:bg-blue-600 transition-colors duration-200"
                            >
                              <Edit className="w-4 h-4" />
                              <span>Modifier</span>
                            </button>
                            <button
                              onClick={() => deleteIntent(selectedIntent._id)}
                              className="bg-red-500 text-white px-3 py-2 rounded-lg flex items-center space-x-2 hover:bg-red-600 transition-colors duration-200"
                            >
                              <Trash2 className="w-4 h-4" />
                              <span>Supprimer</span>
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => saveIntent(selectedIntent)}
                              className="bg-green-500 text-white px-3 py-2 rounded-lg flex items-center space-x-2 hover:bg-green-600 transition-colors duration-200"
                            >
                              <Save className="w-4 h-4" />
                              <span>Sauvegarder</span>
                            </button>
                            <button
                              onClick={() => {
                                setIsEditing(false);
                                setSelectedIntent(null);
                              }}
                              className="bg-gray-500 text-white px-3 py-2 rounded-lg hover:bg-gray-600 transition-colors duration-200"
                            >
                              Annuler
                            </button>
                          </>
                        )}
                      </div>
                    </div>

                    {isEditing ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Nom technique</label>
                            <input
                              type="text"
                              value={selectedIntent.name}
                              onChange={(e) => setSelectedIntent({...selectedIntent, name: e.target.value})}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Nom d'affichage</label>
                            <input
                              type="text"
                              value={selectedIntent.displayName}
                              onChange={(e) => setSelectedIntent({...selectedIntent, displayName: e.target.value})}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                          <textarea
                            value={selectedIntent.description}
                            onChange={(e) => setSelectedIntent({...selectedIntent, description: e.target.value})}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={3}
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Phrases d'entraînement</label>
                          {selectedIntent.trainingPhrases.map((phrase, index) => (
                            <div key={index} className="mb-2">
                              <input
                                type="text"
                                value={phrase.text}
                                onChange={(e) => {
                                  const newPhrases = [...selectedIntent.trainingPhrases];
                                  newPhrases[index] = { ...phrase, text: e.target.value };
                                  setSelectedIntent({...selectedIntent, trainingPhrases: newPhrases});
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                placeholder="Exemple de phrase..."
                              />
                            </div>
                          ))}
                          <button
                            onClick={() => {
                              setSelectedIntent({
                                ...selectedIntent,
                                trainingPhrases: [...selectedIntent.trainingPhrases, { text: '', entities: [] }]
                              });
                            }}
                            className="text-blue-500 hover:text-blue-600 text-sm"
                          >
                            + Ajouter une phrase
                          </button>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Réponses</label>
                          {selectedIntent.responses.map((response, index) => (
                            <div key={index} className="mb-2">
                              <textarea
                                value={response.text}
                                onChange={(e) => {
                                  const newResponses = [...selectedIntent.responses];
                                  newResponses[index] = { ...response, text: e.target.value };
                                  setSelectedIntent({...selectedIntent, responses: newResponses});
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                rows={2}
                                placeholder="Réponse du bot..."
                              />
                            </div>
                          ))}
                          <button
                            onClick={() => {
                              setSelectedIntent({
                                ...selectedIntent,
                                responses: [...selectedIntent.responses, { text: '', quickReplies: [] }]
                              });
                            }}
                            className="text-blue-500 hover:text-blue-600 text-sm"
                          >
                            + Ajouter une réponse
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium text-gray-800 mb-2">Informations</h4>
                          <div className="bg-gray-50 p-4 rounded-lg">
                            <p><strong>Nom:</strong> {selectedIntent.name}</p>
                            <p><strong>Description:</strong> {selectedIntent.description}</p>
                            <p><strong>Priorité:</strong> {selectedIntent.priority}</p>
                            <p><strong>Statut:</strong> {selectedIntent.isActive ? 'Actif' : 'Inactif'}</p>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-800 mb-2">Phrases d'entraînement</h4>
                          <div className="space-y-2">
                            {selectedIntent.trainingPhrases.map((phrase, index) => (
                              <div key={index} className="bg-blue-50 p-3 rounded-lg">
                                <p className="text-sm">{phrase.text}</p>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-800 mb-2">Réponses</h4>
                          <div className="space-y-2">
                            {selectedIntent.responses.map((response, index) => (
                              <div key={index} className="bg-green-50 p-3 rounded-lg">
                                <p className="text-sm">{response.text}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Target className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-600 mb-2">Sélectionnez une intention</h3>
                    <p className="text-gray-500">Choisissez une intention pour voir les détails</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'test' && (
            <div className="max-w-2xl mx-auto space-y-6">
              <div>
                <h3 className="text-lg font-bold text-gray-800 mb-4">Test du moteur NLP</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Message à tester</label>
                    <input
                      type="text"
                      value={testMessage}
                      onChange={(e) => setTestMessage(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Tapez un message pour tester le NLP..."
                      onKeyPress={(e) => e.key === 'Enter' && testNLP()}
                    />
                  </div>

                  <button
                    onClick={testNLP}
                    disabled={isLoading || !testMessage.trim()}
                    className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? 'Test en cours...' : 'Tester le NLP'}
                  </button>
                </div>
              </div>

              {testResult && (
                <div className="bg-white border border-gray-200 rounded-lg p-6">
                  <h4 className="font-bold text-gray-800 mb-4">Résultats du test</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h5 className="font-medium text-gray-700 mb-2">Intention détectée</h5>
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <p className="font-medium">{testResult.intent}</p>
                        <p className="text-sm text-gray-600">Confiance: {(testResult.confidence * 100).toFixed(1)}%</p>
                      </div>
                    </div>

                    <div>
                      <h5 className="font-medium text-gray-700 mb-2">Entités extraites</h5>
                      <div className="space-y-2">
                        {testResult.entities.length > 0 ? (
                          testResult.entities.map((entity: any, index: number) => (
                            <div key={index} className="bg-green-50 p-2 rounded">
                              <p className="text-sm"><strong>{entity.entity}:</strong> {entity.value}</p>
                            </div>
                          ))
                        ) : (
                          <p className="text-sm text-gray-500">Aucune entité détectée</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="mt-6">
                    <h5 className="font-medium text-gray-700 mb-2">Réponse générée</h5>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p>{testResult.response}</p>
                    </div>
                  </div>

                  <div className="mt-4 text-sm text-gray-500">
                    <p>Temps de traitement: {testResult.responseTime}</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NLPManagement;