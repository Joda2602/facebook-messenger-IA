import React, { useState } from 'react';
import { Search, Filter, MessageCircle, Clock, CheckCircle, AlertCircle } from 'lucide-react';

const Conversations: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);

  const conversations = [
    {
      id: 1,
      customer: 'Marie Dubois',
      lastMessage: 'Merci beaucoup pour votre aide !',
      timestamp: '2 min',
      status: 'resolved',
      unread: 0,
      messages: [
        { id: 1, sender: 'customer', text: 'Bonjour, j\'ai une question sur vos produits', time: '14:30' },
        { id: 2, sender: 'bot', text: 'Bonjour Marie ! Je suis ravi de vous aider. Quelle est votre question ?', time: '14:30' },
        { id: 3, sender: 'customer', text: 'Je voudrais connaître les prix de vos services', time: '14:32' },
        { id: 4, sender: 'bot', text: 'Je vais vous mettre en relation avec un conseiller commercial qui pourra vous donner tous les détails sur nos tarifs.', time: '14:32' },
        { id: 5, sender: 'customer', text: 'Merci beaucoup pour votre aide !', time: '14:35' }
      ]
    },
    {
      id: 2,
      customer: 'Pierre Martin',
      lastMessage: 'Pouvez-vous m\'aider avec ma commande ?',
      timestamp: '15 min',
      status: 'active',
      unread: 2,
      messages: [
        { id: 1, sender: 'customer', text: 'Salut', time: '14:15' },
        { id: 2, sender: 'bot', text: 'Bonjour Pierre ! Comment puis-je vous aider aujourd\'hui ?', time: '14:15' },
        { id: 3, sender: 'customer', text: 'Pouvez-vous m\'aider avec ma commande ?', time: '14:17' }
      ]
    },
    {
      id: 3,
      customer: 'Sophie Laurent',
      lastMessage: 'Quels sont vos horaires d\'ouverture ?',
      timestamp: '32 min',
      status: 'pending',
      unread: 1,
      messages: [
        { id: 1, sender: 'customer', text: 'Bonjour', time: '13:45' },
        { id: 2, sender: 'bot', text: 'Bonjour Sophie ! Je suis votre assistant virtuel. Comment puis-je vous aider ?', time: '13:45' },
        { id: 3, sender: 'customer', text: 'Quels sont vos horaires d\'ouverture ?', time: '13:50' }
      ]
    },
    {
      id: 4,
      customer: 'Jean Dupont',
      lastMessage: 'Parfait, merci !',
      timestamp: '1h',
      status: 'resolved',
      unread: 0,
      messages: [
        { id: 1, sender: 'customer', text: 'Bonjour, je cherche des informations sur la livraison', time: '13:00' },
        { id: 2, sender: 'bot', text: 'Bonjour Jean ! Je serais ravi de vous renseigner sur nos options de livraison.', time: '13:00' },
        { id: 3, sender: 'customer', text: 'Parfait, merci !', time: '13:05' }
      ]
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <MessageCircle className="w-4 h-4 text-green-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'resolved':
        return <CheckCircle className="w-4 h-4 text-blue-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'Actif';
      case 'pending':
        return 'En attente';
      case 'resolved':
        return 'Résolu';
      default:
        return 'Inconnu';
    }
  };

  const filteredConversations = conversations.filter(conv => {
    const matchesSearch = conv.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         conv.lastMessage.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || conv.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Conversations</h1>
          <p className="text-gray-600 mt-2">Gérez toutes vos conversations clients</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Conversations List */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-md border border-gray-100">
            {/* Search and Filter */}
            <div className="p-4 border-b border-gray-200">
              <div className="flex space-x-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Rechercher..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">Tous</option>
                  <option value="active">Actif</option>
                  <option value="pending">En attente</option>
                  <option value="resolved">Résolu</option>
                </select>
              </div>
            </div>

            {/* Conversations */}
            <div className="max-h-96 overflow-y-auto">
              {filteredConversations.map((conversation) => (
                <div
                  key={conversation.id}
                  onClick={() => setSelectedConversation(conversation.id)}
                  className={`p-4 border-b border-gray-100 cursor-pointer transition-colors duration-200 hover:bg-gray-50 ${
                    selectedConversation === conversation.id ? 'bg-blue-50 border-blue-200' : ''
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm font-medium">
                          {conversation.customer.charAt(0)}
                        </span>
                      </div>
                      <span className="font-medium text-gray-800">{conversation.customer}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      {conversation.unread > 0 && (
                        <span className="bg-red-500 text-white text-xs font-medium px-2 py-1 rounded-full">
                          {conversation.unread}
                        </span>
                      )}
                      <span className="text-xs text-gray-500">{conversation.timestamp}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-2 truncate">{conversation.lastMessage}</p>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(conversation.status)}
                    <span className="text-xs text-gray-500">{getStatusLabel(conversation.status)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Conversation Detail */}
        <div className="lg:col-span-2">
          {selectedConversation ? (
            <div className="bg-white rounded-xl shadow-md border border-gray-100 h-full">
              {(() => {
                const conversation = conversations.find(c => c.id === selectedConversation);
                if (!conversation) return null;

                return (
                  <>
                    {/* Header */}
                    <div className="p-4 border-b border-gray-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                            <span className="text-white font-medium">
                              {conversation.customer.charAt(0)}
                            </span>
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-800">{conversation.customer}</h3>
                            <div className="flex items-center space-x-2">
                              {getStatusIcon(conversation.status)}
                              <span className="text-sm text-gray-500">{getStatusLabel(conversation.status)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Messages */}
                    <div className="p-4 h-96 overflow-y-auto space-y-4">
                      {conversation.messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.sender === 'customer' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-xs px-4 py-2 rounded-2xl ${
                            message.sender === 'customer'
                              ? 'bg-blue-500 text-white rounded-br-md'
                              : 'bg-gray-100 text-gray-800 rounded-bl-md'
                          }`}>
                            <p className="text-sm">{message.text}</p>
                            <p className={`text-xs mt-1 ${
                              message.sender === 'customer' ? 'text-blue-100' : 'text-gray-500'
                            }`}>
                              {message.time}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Response Input */}
                    <div className="p-4 border-t border-gray-200">
                      <div className="flex space-x-3">
                        <input
                          type="text"
                          placeholder="Tapez votre réponse..."
                          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors duration-200">
                          Envoyer
                        </button>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-md border border-gray-100 h-full flex items-center justify-center">
              <div className="text-center">
                <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-600 mb-2">Sélectionnez une conversation</h3>
                <p className="text-gray-500">Choisissez une conversation pour voir les détails</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Conversations;