import React from 'react';
import { 
  LayoutDashboard, 
  MessageCircle, 
  Settings, 
  BarChart3, 
  Bot, 
  Clock,
  Users,
  Facebook,
  Brain,
  Globe
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'conversations', icon: MessageCircle, label: 'Conversations' },
    { id: 'nlp-management', icon: Brain, label: 'Gestion NLP' },
    { id: 'bot-config', icon: Bot, label: 'Configuration Bot' },
    { id: 'multi-pages', icon: Globe, label: 'Multi-Pages' },
    { id: 'facebook-integration', icon: Facebook, label: 'Intégration Facebook' },
    { id: 'analytics', icon: BarChart3, label: 'Analytics' },
    { id: 'schedule', icon: Clock, label: 'Horaires' },
    { id: 'customers', icon: Users, label: 'Clients' },
    { id: 'settings', icon: Settings, label: 'Paramètres' }
  ];

  return (
    <div className="w-64 bg-white shadow-lg border-r border-gray-200 h-screen">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Facebook className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-800">MessengerBot</h1>
            <p className="text-sm text-gray-500">AI Assistant Pro</p>
          </div>
        </div>
      </div>
      
      <nav className="p-4">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg mb-2 text-left transition-all duration-200 ${
                activeTab === item.id
                  ? 'bg-gradient-to-r from-blue-50 to-purple-50 text-blue-600 border-r-4 border-blue-500 shadow-sm'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-800'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>
      
      <div className="absolute bottom-4 left-4 right-4">
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-100">
          <div className="flex items-center space-x-2 mb-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-gray-700">Système actif</span>
          </div>
          <p className="text-xs text-gray-600">
            NLP • Multi-pages • Analytics
          </p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;