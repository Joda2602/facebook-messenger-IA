import React from 'react';
import { MessageCircle, Users, Clock, TrendingUp, Facebook } from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    {
      title: 'Messages Aujourd\'hui',
      value: '247',
      change: '+12%',
      icon: MessageCircle,
      color: 'bg-blue-500'
    },
    {
      title: 'Clients Actifs',
      value: '89',
      change: '+8%',
      icon: Users,
      color: 'bg-green-500'
    },
    {
      title: 'Temps de Réponse Moyen',
      value: '2.3s',
      change: '-15%',
      icon: Clock,
      color: 'bg-orange-500'
    },
    {
      title: 'Taux de Satisfaction',
      value: '94%',
      change: '+3%',
      icon: TrendingUp,
      color: 'bg-purple-500'
    }
  ];

  const recentConversations = [
    { id: 1, customer: 'Marie Dubois', message: 'Bonjour, j\'ai une question sur...', time: '2min', status: 'active' },
    { id: 2, customer: 'Pierre Martin', message: 'Merci pour votre aide rapide !', time: '15min', status: 'resolved' },
    { id: 3, customer: 'Sophie Laurent', message: 'Pouvez-vous m\'aider avec...', time: '32min', status: 'pending' },
    { id: 4, customer: 'Jean Dupont', message: 'Parfait, problème résolu.', time: '1h', status: 'resolved' }
  ];

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>
          <p className="text-gray-600 mt-2">Aperçu de votre assistant AI Facebook Messenger</p>
        </div>
        <div className="flex items-center space-x-3 bg-green-50 px-4 py-2 rounded-lg">
          <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-green-700 font-medium">Bot Actif</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
                  <p className={`text-sm font-medium ${stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                    {stat.change} vs hier
                  </p>
                </div>
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Conversations */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-800">Conversations Récentes</h2>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {recentConversations.map((conversation) => (
              <div key={conversation.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-medium">{conversation.customer.charAt(0)}</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">{conversation.customer}</p>
                    <p className="text-sm text-gray-600">{conversation.message}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-sm text-gray-500">{conversation.time}</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    conversation.status === 'active' ? 'bg-green-100 text-green-800' :
                    conversation.status === 'resolved' ? 'bg-blue-100 text-blue-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {conversation.status === 'active' ? 'Actif' :
                     conversation.status === 'resolved' ? 'Résolu' : 'En attente'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Facebook Connection Status */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
              <Facebook className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-800">Connexion Facebook</h3>
              <p className="text-gray-600">Page connectée: Mon Entreprise</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            <span className="text-green-700 font-medium">Connecté</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;