# Facebook Messenger AI Assistant

Une application complète pour gérer un assistant IA sur Facebook Messenger.

## 🚀 Fonctionnalités

- **Dashboard** : Vue d'ensemble des performances
- **Conversations** : Gestion des conversations clients
- **Configuration Bot** : Personnalisation des réponses automatiques
- **Intégration Facebook** : Configuration complète avec Facebook Messenger
- **Analytics** : Statistiques détaillées
- **IA Avancée** : Support OpenAI pour des réponses intelligentes

## 📋 Prérequis

1. **Application Facebook** : Créez une app sur [Facebook Developers](https://developers.facebook.com)
2. **Page Facebook** : Une page Facebook pour votre entreprise
3. **Domaine HTTPS** : Pour les webhooks Facebook (requis en production)

## 🛠️ Installation

1. **Cloner et installer les dépendances** :
```bash
npm install
```

2. **Configuration des variables d'environnement** :
```bash
cp .env.example .env
```

Remplissez le fichier `.env` avec vos clés :
```env
FACEBOOK_APP_ID=your_facebook_app_id
FACEBOOK_APP_SECRET=your_facebook_app_secret
FACEBOOK_PAGE_ACCESS_TOKEN=your_page_access_token
FACEBOOK_VERIFY_TOKEN=your_custom_verify_token
OPENAI_API_KEY=your_openai_api_key (optionnel)
PORT=3001
WEBHOOK_URL=https://your-domain.com/webhook
```

3. **Démarrer l'application** :
```bash
# Frontend (développement)
npm run dev

# Backend (serveur)
npm run server
```

## 🔧 Configuration Facebook

### 1. Créer une Application Facebook

1. Allez sur [Facebook Developers](https://developers.facebook.com)
2. Créez une nouvelle application
3. Ajoutez le produit "Messenger"

### 2. Configurer Messenger

1. Dans les paramètres Messenger, générez un **Page Access Token**
2. Configurez les **Webhooks** :
   - URL de callback : `https://votre-domaine.com/webhook`
   - Token de vérification : votre token personnalisé
   - Événements : `messages`, `messaging_postbacks`

### 3. Permissions

Assurez-vous d'avoir les permissions :
- `pages_messaging`
- `pages_read_engagement`

## 🤖 Configuration de l'IA

### Réponses Automatiques (par défaut)

Le bot inclut des réponses prédéfinies pour :
- Salutations (`bonjour`, `salut`)
- Demandes de prix (`prix`, `tarif`)
- Horaires (`horaire`, `ouvert`)
- Support (`support`, `aide`)

### IA Avancée avec OpenAI

Pour des réponses plus intelligentes, ajoutez votre clé OpenAI dans `.env` :
```env
OPENAI_API_KEY=sk-...
```

## 📊 Fonctionnalités Principales

### Dashboard
- Statistiques en temps réel
- Conversations récentes
- Statut de connexion Facebook

### Gestion des Conversations
- Interface de chat en temps réel
- Historique des messages
- Statuts des conversations

### Configuration du Bot
- Personnalisation des réponses
- Paramètres avancés
- Test de l'IA

### Analytics
- Métriques de performance
- Temps de réponse
- Satisfaction client

## 🚀 Déploiement

### Développement Local avec ngrok

Pour tester les webhooks localement :
```bash
# Installer ngrok
npm install -g ngrok

# Exposer le port local
ngrok http 3001

# Utiliser l'URL HTTPS générée comme webhook
```

### Production

1. **Déployez sur un serveur avec HTTPS**
2. **Configurez les variables d'environnement**
3. **Mettez à jour l'URL du webhook dans Facebook**

## 🔒 Sécurité

- Toutes les communications avec Facebook utilisent HTTPS
- Les tokens sont stockés de manière sécurisée
- Validation des webhooks Facebook

## 📝 API Endpoints

- `GET /webhook` : Vérification du webhook Facebook
- `POST /webhook` : Réception des messages Facebook
- `POST /api/ai/test` : Test de l'IA
- `GET /api/health` : Vérification de l'état du serveur

## 🐛 Dépannage

### Webhook non vérifié
- Vérifiez que l'URL est accessible en HTTPS
- Confirmez que le token de vérification correspond

### Messages non reçus
- Vérifiez les permissions de la page
- Confirmez que le Page Access Token est valide

### Erreurs d'IA
- Vérifiez la clé OpenAI (si utilisée)
- Consultez les logs du serveur

## 📞 Support

Pour toute question ou problème, consultez la documentation Facebook Messenger Platform ou créez une issue dans ce repository.