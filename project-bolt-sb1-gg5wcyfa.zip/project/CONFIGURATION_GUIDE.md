# 🚀 Guide de Configuration - Facebook Messenger AI Platform

## 📋 Table des matières
1. [Prérequis](#prérequis)
2. [Configuration de la base de données](#configuration-de-la-base-de-données)
3. [Configuration Facebook](#configuration-facebook)
4. [Variables d'environnement](#variables-denvironnement)
5. [Déploiement](#déploiement)
6. [Tests et validation](#tests-et-validation)

---

## 🔧 Prérequis

### Logiciels requis
- **Node.js** (version 18 ou supérieure)
- **MongoDB** (version 5.0 ou supérieure)
- **Git**
- **Un éditeur de code** (VS Code recommandé)

### Comptes nécessaires
- **Compte Facebook Developer** (gratuit)
- **Page Facebook** pour votre entreprise
- **Domaine HTTPS** (pour la production)
- **Compte MongoDB Atlas** (optionnel, pour le cloud)

---

## 🗄️ Configuration de la base de données

### Option 1: MongoDB Local

1. **Installer MongoDB**
   ```bash
   # Sur Ubuntu/Debian
   sudo apt-get install mongodb
   
   # Sur macOS avec Homebrew
   brew install mongodb-community
   
   # Sur Windows
   # Télécharger depuis https://www.mongodb.com/try/download/community
   ```

2. **Démarrer MongoDB**
   ```bash
   # Linux/macOS
   sudo systemctl start mongod
   
   # Ou directement
   mongod
   ```

3. **Créer la base de données**
   ```bash
   mongo
   use facebook-messenger-ai
   ```

### Option 2: MongoDB Atlas (Cloud - Recommandé)

1. **Créer un compte** sur [MongoDB Atlas](https://www.mongodb.com/atlas)

2. **Créer un cluster**
   - Choisir le plan gratuit (M0)
   - Sélectionner une région proche
   - Nommer votre cluster

3. **Configurer l'accès**
   - Créer un utilisateur de base de données
   - Ajouter votre IP à la whitelist (ou 0.0.0.0/0 pour tous)

4. **Récupérer l'URI de connexion**
   ```
   mongodb+srv://username:password@cluster.mongodb.net/facebook-messenger-ai
   ```

---

## 📱 Configuration Facebook

### Étape 1: Créer une application Facebook

1. **Aller sur Facebook Developers**
   - Visitez [developers.facebook.com](https://developers.facebook.com)
   - Connectez-vous avec votre compte Facebook

2. **Créer une nouvelle app**
   - Cliquer sur "Créer une app"
   - Choisir "Entreprise" comme type d'app
   - Remplir les informations de base

3. **Ajouter Messenger**
   - Dans le tableau de bord, cliquer sur "Ajouter un produit"
   - Sélectionner "Messenger"

### Étape 2: Configuration Messenger

1. **Générer un Page Access Token**
   - Dans Messenger > Paramètres
   - Sélectionner votre page Facebook
   - Générer le token et le copier

2. **Configurer les webhooks**
   - URL de callback: `https://votre-domaine.com/webhook`
   - Token de vérification: créer un token personnalisé (ex: `mon_token_secret_123`)
   - Événements à souscrire:
     - `messages`
     - `messaging_postbacks`
     - `messaging_optins`

3. **Récupérer l'App ID et App Secret**
   - Dans Paramètres > Général
   - Copier l'ID de l'app et la clé secrète

### Étape 3: Configuration de la page

1. **Permissions requises**
   - `pages_messaging`
   - `pages_read_engagement`
   - `pages_show_list`

2. **Vérification de l'app** (pour la production)
   - Soumettre l'app pour révision Facebook
   - Fournir les cas d'usage et captures d'écran

---

## ⚙️ Variables d'environnement

### Créer le fichier .env

```bash
cp .env.example .env
```

### Remplir les variables

```env
# Base de données
MONGODB_URI=mongodb://localhost:27017/facebook-messenger-ai
# Ou pour Atlas: mongodb+srv://username:password@cluster.mongodb.net/facebook-messenger-ai

# Facebook Configuration
FACEBOOK_APP_ID=votre_app_id_facebook
FACEBOOK_APP_SECRET=votre_app_secret_facebook
FACEBOOK_PAGE_ACCESS_TOKEN=votre_page_access_token
FACEBOOK_VERIFY_TOKEN=votre_token_verification_personnalise

# OpenAI (optionnel pour IA avancée)
OPENAI_API_KEY=sk-votre_cle_openai

# Sécurité
JWT_SECRET=votre_jwt_secret_tres_long_et_complexe
BCRYPT_ROUNDS=12

# Serveur
PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:5173

# Webhook URL (pour la production)
WEBHOOK_URL=https://votre-domaine.com/webhook

# Logging
LOG_LEVEL=info
```

### Générer des secrets sécurisés

```bash
# Générer un JWT secret
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

# Générer un token de vérification
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## 🚀 Déploiement

### Développement local

1. **Installer les dépendances**
   ```bash
   npm install
   ```

2. **Démarrer la base de données**
   ```bash
   # Si MongoDB local
   mongod
   ```

3. **Démarrer l'application**
   ```bash
   # Terminal 1: Backend
   npm run server
   
   # Terminal 2: Frontend
   npm run dev
   ```

4. **Exposer le webhook localement** (pour les tests)
   ```bash
   # Installer ngrok
   npm install -g ngrok
   
   # Exposer le port 3001
   ngrok http 3001
   
   # Utiliser l'URL HTTPS générée comme webhook
   ```

### Production

#### Option 1: Serveur VPS

1. **Préparer le serveur**
   ```bash
   # Installer Node.js
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Installer PM2 pour la gestion des processus
   npm install -g pm2
   ```

2. **Déployer l'application**
   ```bash
   # Cloner le repository
   git clone votre-repository
   cd facebook-messenger-ai
   
   # Installer les dépendances
   npm install
   
   # Build du frontend
   npm run build
   
   # Démarrer avec PM2
   pm2 start ecosystem.config.js
   ```

3. **Configurer Nginx** (optionnel)
   ```nginx
   server {
       listen 80;
       server_name votre-domaine.com;
       
       location / {
           proxy_pass http://localhost:3001;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

#### Option 2: Heroku

1. **Créer l'application**
   ```bash
   heroku create votre-app-name
   ```

2. **Configurer les variables**
   ```bash
   heroku config:set MONGODB_URI=votre_mongodb_uri
   heroku config:set FACEBOOK_APP_ID=votre_app_id
   # ... autres variables
   ```

3. **Déployer**
   ```bash
   git push heroku main
   ```

#### Option 3: Vercel/Netlify

1. **Connecter le repository**
2. **Configurer les variables d'environnement**
3. **Déployer automatiquement**

---

## ✅ Tests et validation

### 1. Vérifier la connexion à la base de données

```bash
# Tester la connexion
curl http://localhost:3001/api/health
```

### 2. Vérifier le webhook Facebook

```bash
# Test de vérification
curl "http://localhost:3001/webhook?hub.mode=subscribe&hub.verify_token=votre_token&hub.challenge=test"
```

### 3. Tester l'IA

```bash
# Test de l'API IA
curl -X POST http://localhost:3001/api/ai/test \
  -H "Content-Type: application/json" \
  -d '{"message": "Bonjour"}'
```

### 4. Tester l'interface

1. Ouvrir `http://localhost:5173`
2. Naviguer dans les différentes sections
3. Tester la création d'intentions NLP
4. Vérifier les analytics

---

## 🔧 Dépannage courant

### Problème: Webhook non vérifié

**Solution:**
- Vérifier que l'URL est accessible en HTTPS
- Confirmer que le token de vérification correspond
- Vérifier les logs du serveur

### Problème: Messages non reçus

**Solution:**
- Vérifier les permissions de la page
- Confirmer que le Page Access Token est valide
- Vérifier que l'app est en mode développement ou approuvée

### Problème: Erreurs de base de données

**Solution:**
- Vérifier la connexion MongoDB
- Confirmer l'URI de connexion
- Vérifier les permissions utilisateur

### Problème: Erreurs d'IA

**Solution:**
- Vérifier la clé OpenAI (si utilisée)
- Consulter les logs du serveur
- Tester avec des messages simples

---

## 📞 Support et ressources

- **Documentation Facebook Messenger**: [developers.facebook.com/docs/messenger-platform](https://developers.facebook.com/docs/messenger-platform)
- **MongoDB Documentation**: [docs.mongodb.com](https://docs.mongodb.com)
- **OpenAI API**: [platform.openai.com/docs](https://platform.openai.com/docs)

---

## 🎯 Checklist de déploiement

- [ ] Base de données configurée et accessible
- [ ] Variables d'environnement définies
- [ ] Application Facebook créée
- [ ] Page Access Token généré
- [ ] Webhook configuré et vérifié
- [ ] Tests locaux réussis
- [ ] Déploiement en production
- [ ] Tests de production
- [ ] Monitoring activé
- [ ] Sauvegardes configurées

---

**🎉 Félicitations ! Votre plateforme Facebook Messenger AI est maintenant opérationnelle !**