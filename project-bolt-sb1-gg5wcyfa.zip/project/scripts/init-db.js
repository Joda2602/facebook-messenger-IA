import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from '../server/models/User.js';
import BotConfig from '../server/models/BotConfig.js';
import Intent from '../server/models/Intent.js';
import Entity from '../server/models/Entity.js';
import FacebookPage from '../server/models/FacebookPage.js';

dotenv.config();

const initializeDatabase = async () => {
  try {
    console.log('🔄 Connexion à MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/facebook-messenger-ai');
    console.log('✅ Connecté à MongoDB');

    // Créer un utilisateur admin par défaut
    const adminExists = await User.findOne({ role: 'admin' });
    if (!adminExists) {
      console.log('👤 Création de l\'utilisateur admin...');
      const admin = new User({
        email: 'admin@example.com',
        password: 'admin123',
        firstName: 'Admin',
        lastName: 'System',
        role: 'admin',
        emailVerified: true,
        company: {
          name: 'Demo Company',
          industry: 'Technology'
        }
      });
      await admin.save();
      console.log('✅ Utilisateur admin créé (email: admin@example.com, password: admin123)');
    }

    // Créer une configuration bot par défaut
    const botConfigExists = await BotConfig.findOne();
    if (!botConfigExists) {
      console.log('🤖 Création de la configuration bot par défaut...');
      const admin = await User.findOne({ role: 'admin' });
      
      const botConfig = new BotConfig({
        name: 'Assistant virtuel',
        personality: 'Amical et professionnel',
        systemPrompt: `Tu es un assistant virtuel professionnel et amical pour une entreprise. 
                       Réponds de manière concise et utile. Si tu ne peux pas aider directement, 
                       propose de mettre en relation avec un conseiller humain.
                       Réponds toujours en français et reste dans le contexte de l'entreprise.`,
        welcomeMessage: "Bonjour ! Je suis votre assistant virtuel. Comment puis-je vous aider aujourd'hui ?",
        faq: [
          {
            question: "Quels sont vos horaires d'ouverture ?",
            answer: "Nous sommes ouverts du lundi au vendredi de 9h à 18h, et le samedi de 9h à 17h.",
            keywords: ["horaire", "ouvert", "fermé", "heure"]
          },
          {
            question: "Comment puis-je vous contacter ?",
            answer: "Vous pouvez nous contacter via ce chat, par email ou par téléphone. Un conseiller peut également vous rappeler.",
            keywords: ["contact", "téléphone", "email", "joindre"]
          },
          {
            question: "Quels sont vos tarifs ?",
            answer: "Nos tarifs varient selon vos besoins. Je vais vous mettre en relation avec un conseiller commercial pour une offre personnalisée.",
            keywords: ["prix", "tarif", "coût", "combien"]
          }
        ],
        automatedResponses: [
          {
            trigger: "bonjour",
            response: "Bonjour ! Je suis ravi de vous voir. Comment puis-je vous aider aujourd'hui ?",
            priority: 10
          },
          {
            trigger: "salut",
            response: "Salut ! Comment puis-je vous aider ?",
            priority: 8
          },
          {
            trigger: "merci",
            response: "Je vous en prie ! N'hésitez pas si vous avez d'autres questions.",
            priority: 5
          },
          {
            trigger: "au revoir",
            response: "Au revoir ! Passez une excellente journée et n'hésitez pas à revenir si vous avez besoin d'aide.",
            priority: 5
          }
        ],
        createdBy: admin._id
      });
      await botConfig.save();
      console.log('✅ Configuration bot créée');
    }

    // Créer des intents par défaut
    const intentExists = await Intent.findOne();
    if (!intentExists) {
      console.log('🎯 Création des intents par défaut...');
      const admin = await User.findOne({ role: 'admin' });
      
      const defaultIntents = [
        {
          name: 'greeting',
          displayName: 'Salutations',
          description: 'Gérer les salutations et messages de bienvenue',
          trainingPhrases: [
            { text: 'bonjour', entities: [] },
            { text: 'salut', entities: [] },
            { text: 'hello', entities: [] },
            { text: 'bonsoir', entities: [] },
            { text: 'hey', entities: [] }
          ],
          responses: [
            { text: 'Bonjour ! Comment puis-je vous aider aujourd\'hui ?', quickReplies: ['Horaires', 'Tarifs', 'Contact'] },
            { text: 'Salut ! Ravi de vous voir. Que puis-je faire pour vous ?', quickReplies: ['Informations', 'Support'] }
          ],
          priority: 10,
          createdBy: admin._id
        },
        {
          name: 'pricing',
          displayName: 'Demandes de prix',
          description: 'Gérer les questions sur les tarifs et prix',
          trainingPhrases: [
            { text: 'quel est le prix', entities: [] },
            { text: 'combien ça coûte', entities: [] },
            { text: 'tarifs', entities: [] },
            { text: 'prix', entities: [] },
            { text: 'coût', entities: [] }
          ],
          responses: [
            { text: 'Je vais vous mettre en relation avec un conseiller commercial qui pourra vous donner tous les détails sur nos tarifs.', quickReplies: ['Oui merci', 'Plus tard'] }
          ],
          priority: 8,
          createdBy: admin._id
        },
        {
          name: 'hours',
          displayName: 'Horaires d\'ouverture',
          description: 'Informations sur les horaires d\'ouverture',
          trainingPhrases: [
            { text: 'quels sont vos horaires', entities: [] },
            { text: 'êtes-vous ouverts', entities: [] },
            { text: 'horaires d\'ouverture', entities: [] },
            { text: 'à quelle heure fermez-vous', entities: [] }
          ],
          responses: [
            { text: 'Nous sommes ouverts du lundi au vendredi de 9h à 18h, et le samedi de 9h à 17h. Nous sommes fermés le dimanche.', quickReplies: ['Merci', 'Contact'] }
          ],
          priority: 7,
          createdBy: admin._id
        },
        {
          name: 'goodbye',
          displayName: 'Au revoir',
          description: 'Gérer les messages d\'au revoir',
          trainingPhrases: [
            { text: 'au revoir', entities: [] },
            { text: 'bye', entities: [] },
            { text: 'à bientôt', entities: [] },
            { text: 'merci au revoir', entities: [] }
          ],
          responses: [
            { text: 'Au revoir ! Passez une excellente journée et n\'hésitez pas à revenir si vous avez besoin d\'aide.', quickReplies: [] }
          ],
          priority: 5,
          createdBy: admin._id
        }
      ];

      for (const intentData of defaultIntents) {
        const intent = new Intent(intentData);
        await intent.save();
      }
      console.log('✅ Intents par défaut créés');
    }

    // Créer des entités par défaut
    const entityExists = await Entity.findOne();
    if (!entityExists) {
      console.log('🏷️  Création des entités par défaut...');
      const admin = await User.findOne({ role: 'admin' });
      
      const defaultEntities = [
        {
          name: 'time',
          displayName: 'Temps',
          entityType: 'system',
          values: [
            { value: 'matin', synonyms: ['matinée', 'am'] },
            { value: 'après-midi', synonyms: ['pm', 'aprem'] },
            { value: 'soir', synonyms: ['soirée', 'evening'] }
          ],
          createdBy: admin._id
        },
        {
          name: 'product',
          displayName: 'Produits',
          entityType: 'custom',
          values: [
            { value: 'service', synonyms: ['prestation', 'offre'] },
            { value: 'produit', synonyms: ['article', 'item'] },
            { value: 'consultation', synonyms: ['conseil', 'expertise'] }
          ],
          createdBy: admin._id
        }
      ];

      for (const entityData of defaultEntities) {
        const entity = new Entity(entityData);
        await entity.save();
      }
      console.log('✅ Entités par défaut créées');
    }

    console.log('🎉 Initialisation de la base de données terminée !');
    console.log('');
    console.log('📋 Informations de connexion :');
    console.log('   Email: admin@example.com');
    console.log('   Mot de passe: admin123');
    console.log('');
    console.log('🚀 Vous pouvez maintenant démarrer l\'application !');

  } catch (error) {
    console.error('❌ Erreur lors de l\'initialisation:', error);
  } finally {
    await mongoose.disconnect();
  }
};

initializeDatabase();