#!/bin/bash

echo "🚀 Configuration de Facebook Messenger AI Platform"
echo "=================================================="

# Vérifier Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js n'est pas installé. Veuillez l'installer depuis https://nodejs.org"
    exit 1
fi

echo "✅ Node.js détecté: $(node --version)"

# Vérifier MongoDB
if ! command -v mongod &> /dev/null; then
    echo "⚠️  MongoDB n'est pas installé localement."
    echo "   Vous pouvez utiliser MongoDB Atlas (cloud) à la place."
    read -p "   Continuer sans MongoDB local? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "   Installez MongoDB depuis https://www.mongodb.com/try/download/community"
        exit 1
    fi
else
    echo "✅ MongoDB détecté"
fi

# Installer les dépendances
echo "📦 Installation des dépendances..."
npm install

# Créer le fichier .env s'il n'existe pas
if [ ! -f .env ]; then
    echo "⚙️  Création du fichier .env..."
    cp .env.example .env
    
    # Générer des secrets
    JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")
    VERIFY_TOKEN=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
    
    # Remplacer les valeurs dans .env
    sed -i "s/your_jwt_secret_tres_long_et_complexe/$JWT_SECRET/g" .env
    sed -i "s/your_custom_verify_token/$VERIFY_TOKEN/g" .env
    
    echo "✅ Fichier .env créé avec des secrets générés automatiquement"
    echo "⚠️  IMPORTANT: Vous devez encore configurer les variables Facebook:"
    echo "   - FACEBOOK_APP_ID"
    echo "   - FACEBOOK_APP_SECRET" 
    echo "   - FACEBOOK_PAGE_ACCESS_TOKEN"
    echo "   - MONGODB_URI (si vous utilisez Atlas)"
else
    echo "✅ Fichier .env existe déjà"
fi

# Créer les dossiers nécessaires
mkdir -p logs
mkdir -p uploads

echo ""
echo "🎉 Configuration terminée !"
echo ""
echo "📋 Prochaines étapes:"
echo "1. Configurer les variables Facebook dans .env"
echo "2. Démarrer MongoDB (si local): mongod"
echo "3. Démarrer le serveur: npm run server"
echo "4. Démarrer le frontend: npm run dev"
echo ""
echo "📖 Consultez CONFIGURATION_GUIDE.md pour plus de détails"