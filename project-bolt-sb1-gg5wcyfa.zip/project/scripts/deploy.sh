#!/bin/bash

echo "🚀 Déploiement de Facebook Messenger AI Platform"
echo "==============================================="

# Vérifier que nous sommes dans le bon répertoire
if [ ! -f "package.json" ]; then
    echo "❌ Erreur: package.json non trouvé. Exécutez ce script depuis la racine du projet."
    exit 1
fi

# Vérifier les variables d'environnement critiques
if [ -z "$MONGODB_URI" ] || [ -z "$FACEBOOK_APP_ID" ]; then
    echo "❌ Variables d'environnement manquantes. Vérifiez votre fichier .env"
    exit 1
fi

echo "✅ Variables d'environnement vérifiées"

# Installer les dépendances
echo "📦 Installation des dépendances..."
npm ci --only=production

# Build du frontend
echo "🏗️  Build du frontend..."
npm run build

# Vérifier que le build a réussi
if [ ! -d "dist" ]; then
    echo "❌ Erreur: Le build du frontend a échoué"
    exit 1
fi

echo "✅ Build terminé avec succès"

# Démarrer avec PM2 si disponible
if command -v pm2 &> /dev/null; then
    echo "🔄 Démarrage avec PM2..."
    pm2 stop facebook-messenger-ai 2>/dev/null || true
    pm2 start ecosystem.config.js
    pm2 save
    echo "✅ Application démarrée avec PM2"
else
    echo "⚠️  PM2 non installé. Démarrage direct..."
    echo "💡 Installez PM2 pour une meilleure gestion: npm install -g pm2"
    NODE_ENV=production node server/index.js &
    echo "✅ Application démarrée"
fi

echo ""
echo "🎉 Déploiement terminé !"
echo "🌐 Application accessible sur: http://localhost:$PORT"
echo "📊 Health check: http://localhost:$PORT/api/health"