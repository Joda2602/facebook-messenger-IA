import express from 'express';
import axios from 'axios';
import aiService from '../services/aiService.js';
import conversationService from '../services/conversationService.js';

const router = express.Router();

// Vérification du webhook Facebook
router.get('/', (req, res) => {
  const VERIFY_TOKEN = process.env.FACEBOOK_VERIFY_TOKEN;
  
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  
  if (mode && token) {
    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
      console.log('✅ Webhook vérifié avec succès');
      res.status(200).send(challenge);
    } else {
      console.log('❌ Échec de la vérification du webhook');
      res.sendStatus(403);
    }
  } else {
    res.sendStatus(400);
  }
});

// Réception des messages Facebook
router.post('/', async (req, res) => {
  const body = req.body;
  
  if (body.object === 'page') {
    body.entry.forEach(async (entry) => {
      const webhookEvent = entry.messaging[0];
      console.log('📨 Événement reçu:', JSON.stringify(webhookEvent, null, 2));
      
      if (webhookEvent.message) {
        await handleMessage(webhookEvent);
      }
    });
    
    res.status(200).send('EVENT_RECEIVED');
  } else {
    res.sendStatus(404);
  }
});

// Gestion des messages entrants
async function handleMessage(event) {
  const senderId = event.sender.id;
  const messageText = event.message.text;
  
  if (!messageText) return;
  
  try {
    // Sauvegarder le message entrant
    await conversationService.saveMessage({
      senderId,
      message: messageText,
      sender: 'user',
      timestamp: new Date()
    });
    
    // Générer une réponse avec l'IA
    const aiResponse = await aiService.generateResponse(messageText, senderId);
    
    // Envoyer la réponse
    await sendMessage(senderId, aiResponse);
    
    // Sauvegarder la réponse du bot
    await conversationService.saveMessage({
      senderId,
      message: aiResponse,
      sender: 'bot',
      timestamp: new Date()
    });
    
    console.log('✅ Message traité avec succès');
    
  } catch (error) {
    console.error('❌ Erreur lors du traitement du message:', error);
    
    // Envoyer un message d'erreur générique
    await sendMessage(senderId, "Désolé, je rencontre un problème technique. Un conseiller va vous contacter rapidement.");
  }
}

// Envoi de message via l'API Facebook
async function sendMessage(recipientId, messageText) {
  const PAGE_ACCESS_TOKEN = process.env.FACEBOOK_PAGE_ACCESS_TOKEN;
  
  const requestBody = {
    recipient: {
      id: recipientId
    },
    message: {
      text: messageText
    }
  };
  
  try {
    const response = await axios.post(
      `https://graph.facebook.com/v18.0/me/messages?access_token=${PAGE_ACCESS_TOKEN}`,
      requestBody,
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );
    
    console.log('📤 Message envoyé:', messageText);
    return response.data;
    
  } catch (error) {
    console.error('❌ Erreur envoi message:', error.response?.data || error.message);
    throw error;
  }
}

export default router;