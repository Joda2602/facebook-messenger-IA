import express from 'express';
import Intent from '../models/Intent.js';
import Entity from '../models/Entity.js';
import nlpService from '../services/nlpService.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { aiRateLimit } from '../middleware/security.js';

const router = express.Router();

// Appliquer le rate limiting
router.use(aiRateLimit);

// Routes pour les intents
router.get('/intents', asyncHandler(async (req, res) => {
  const intents = await Intent.find({ isActive: true })
    .populate('createdBy', 'email')
    .sort({ priority: -1, createdAt: -1 });
  
  res.json({
    success: true,
    data: intents
  });
}));

router.post('/intents', asyncHandler(async (req, res) => {
  const intent = new Intent({
    ...req.body,
    createdBy: req.user?.id || '507f1f77bcf86cd799439011' // Utilisateur par défaut pour les tests
  });
  
  await intent.save();
  await nlpService.reloadModels();
  
  res.status(201).json({
    success: true,
    data: intent
  });
}));

router.put('/intents/:id', asyncHandler(async (req, res) => {
  const intent = await Intent.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true, runValidators: true }
  );
  
  if (!intent) {
    return res.status(404).json({
      success: false,
      error: { message: 'Intent non trouvé' }
    });
  }
  
  await nlpService.reloadModels();
  
  res.json({
    success: true,
    data: intent
  });
}));

router.delete('/intents/:id', asyncHandler(async (req, res) => {
  const intent = await Intent.findByIdAndUpdate(
    req.params.id,
    { isActive: false },
    { new: true }
  );
  
  if (!intent) {
    return res.status(404).json({
      success: false,
      error: { message: 'Intent non trouvé' }
    });
  }
  
  await nlpService.reloadModels();
  
  res.json({
    success: true,
    message: 'Intent désactivé avec succès'
  });
}));

// Routes pour les entités
router.get('/entities', asyncHandler(async (req, res) => {
  const entities = await Entity.find({ isActive: true })
    .populate('createdBy', 'email')
    .sort({ createdAt: -1 });
  
  res.json({
    success: true,
    data: entities
  });
}));

router.post('/entities', asyncHandler(async (req, res) => {
  const entity = new Entity({
    ...req.body,
    createdBy: req.user?.id || '507f1f77bcf86cd799439011'
  });
  
  await entity.save();
  await nlpService.reloadModels();
  
  res.status(201).json({
    success: true,
    data: entity
  });
}));

// Test du NLP
router.post('/test', asyncHandler(async (req, res) => {
  const { message, context } = req.body;
  
  if (!message) {
    return res.status(400).json({
      success: false,
      error: { message: 'Message requis' }
    });
  }
  
  const startTime = Date.now();
  const result = await nlpService.processMessage(message, context || {});
  const responseTime = Date.now() - startTime;
  
  res.json({
    success: true,
    data: {
      ...result,
      responseTime: `${responseTime}ms`
    }
  });
}));

// Entraîner le modèle
router.post('/train', asyncHandler(async (req, res) => {
  await nlpService.reloadModels();
  
  res.json({
    success: true,
    message: 'Modèle NLP rechargé avec succès'
  });
}));

export default router;