import express from 'express';
import FacebookPage from '../models/FacebookPage.js';
import facebookService from '../services/facebookService.js';
import { asyncHandler } from '../middleware/errorHandler.js';

const router = express.Router();

// Obtenir toutes les pages
router.get('/', asyncHandler(async (req, res) => {
  const pages = await FacebookPage.find({ isActive: true })
    .populate('createdBy', 'email')
    .sort({ createdAt: -1 });
  
  res.json({
    success: true,
    data: pages
  });
}));

// Ajouter une nouvelle page
router.post('/', asyncHandler(async (req, res) => {
  const { pageId, accessToken, settings } = req.body;
  
  if (!pageId || !accessToken) {
    return res.status(400).json({
      success: false,
      error: { message: 'Page ID et Access Token requis' }
    });
  }
  
  const page = await facebookService.addPage({
    pageId,
    accessToken,
    settings
  }, req.user?.id || '507f1f77bcf86cd799439011');
  
  res.status(201).json({
    success: true,
    data: page
  });
}));

// Mettre à jour une page
router.put('/:pageId', asyncHandler(async (req, res) => {
  const { pageId } = req.params;
  const updates = req.body;
  
  const page = await FacebookPage.findOneAndUpdate(
    { pageId },
    updates,
    { new: true, runValidators: true }
  );
  
  if (!page) {
    return res.status(404).json({
      success: false,
      error: { message: 'Page non trouvée' }
    });
  }
  
  // Mettre à jour les paramètres Facebook si nécessaire
  if (updates.settings) {
    await facebookService.setPageSettings(pageId, updates.settings);
  }
  
  await facebookService.reloadPages();
  
  res.json({
    success: true,
    data: page
  });
}));

// Supprimer une page
router.delete('/:pageId', asyncHandler(async (req, res) => {
  const { pageId } = req.params;
  
  await facebookService.removePage(pageId);
  
  res.json({
    success: true,
    message: 'Page supprimée avec succès'
  });
}));

// Obtenir les statistiques d'une page
router.get('/:pageId/stats', asyncHandler(async (req, res) => {
  const { pageId } = req.params;
  
  const page = await FacebookPage.findOne({ pageId });
  if (!page) {
    return res.status(404).json({
      success: false,
      error: { message: 'Page non trouvée' }
    });
  }
  
  res.json({
    success: true,
    data: page.analytics
  });
}));

// Tester l'envoi de message
router.post('/:pageId/test-message', asyncHandler(async (req, res) => {
  const { pageId } = req.params;
  const { recipientId, message } = req.body;
  
  if (!recipientId || !message) {
    return res.status(400).json({
      success: false,
      error: { message: 'Recipient ID et message requis' }
    });
  }
  
  const result = await facebookService.sendMessage(pageId, recipientId, message);
  
  res.json({
    success: true,
    data: result
  });
}));

export default router;