import express from 'express';
import Conversation from '../models/Conversation.js';
import FacebookPage from '../models/FacebookPage.js';
import { asyncHandler } from '../middleware/errorHandler.js';

const router = express.Router();

// Statistiques générales
router.get('/overview', asyncHandler(async (req, res) => {
  const { startDate, endDate, pageId } = req.query;
  
  const dateFilter = {};
  if (startDate) dateFilter.$gte = new Date(startDate);
  if (endDate) dateFilter.$lte = new Date(endDate);
  
  const filter = {};
  if (Object.keys(dateFilter).length > 0) {
    filter.createdAt = dateFilter;
  }
  if (pageId) filter.pageId = pageId;
  
  const [
    totalConversations,
    activeConversations,
    totalMessages,
    avgResponseTime,
    satisfactionStats
  ] = await Promise.all([
    Conversation.countDocuments(filter),
    Conversation.countDocuments({ ...filter, status: 'active' }),
    Conversation.aggregate([
      { $match: filter },
      { $unwind: '$messages' },
      { $count: 'total' }
    ]),
    Conversation.aggregate([
      { $match: { ...filter, averageResponseTime: { $exists: true } } },
      { $group: { _id: null, avg: { $avg: '$averageResponseTime' } } }
    ]),
    Conversation.aggregate([
      { $match: { ...filter, satisfactionRating: { $exists: true } } },
      {
        $group: {
          _id: null,
          avgRating: { $avg: '$satisfactionRating' },
          totalRatings: { $sum: 1 }
        }
      }
    ])
  ]);
  
  res.json({
    success: true,
    data: {
      totalConversations,
      activeConversations,
      totalMessages: totalMessages[0]?.total || 0,
      averageResponseTime: avgResponseTime[0]?.avg || 0,
      satisfactionRate: satisfactionStats[0]?.avgRating || 0,
      totalRatings: satisfactionStats[0]?.totalRatings || 0
    }
  });
}));

// Statistiques par période
router.get('/timeline', asyncHandler(async (req, res) => {
  const { period = 'day', pageId } = req.query;
  
  let groupBy;
  switch (period) {
    case 'hour':
      groupBy = {
        year: { $year: '$createdAt' },
        month: { $month: '$createdAt' },
        day: { $dayOfMonth: '$createdAt' },
        hour: { $hour: '$createdAt' }
      };
      break;
    case 'day':
      groupBy = {
        year: { $year: '$createdAt' },
        month: { $month: '$createdAt' },
        day: { $dayOfMonth: '$createdAt' }
      };
      break;
    case 'month':
      groupBy = {
        year: { $year: '$createdAt' },
        month: { $month: '$createdAt' }
      };
      break;
    default:
      groupBy = {
        year: { $year: '$createdAt' },
        month: { $month: '$createdAt' },
        day: { $dayOfMonth: '$createdAt' }
      };
  }
  
  const filter = {};
  if (pageId) filter.pageId = pageId;
  
  const timeline = await Conversation.aggregate([
    { $match: filter },
    {
      $group: {
        _id: groupBy,
        conversations: { $sum: 1 },
        messages: { $sum: { $size: '$messages' } },
        avgResponseTime: { $avg: '$averageResponseTime' }
      }
    },
    { $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1, '_id.hour': 1 } }
  ]);
  
  res.json({
    success: true,
    data: timeline
  });
}));

// Top intents
router.get('/intents', asyncHandler(async (req, res) => {
  const { pageId } = req.query;
  
  const filter = {};
  if (pageId) filter.pageId = pageId;
  
  const intents = await Conversation.aggregate([
    { $match: filter },
    { $unwind: '$messages' },
    { $match: { 'messages.intent': { $exists: true, $ne: null } } },
    {
      $group: {
        _id: '$messages.intent',
        count: { $sum: 1 },
        avgConfidence: { $avg: '$messages.confidence' }
      }
    },
    { $sort: { count: -1 } },
    { $limit: 10 }
  ]);
  
  res.json({
    success: true,
    data: intents
  });
}));

// Statistiques de satisfaction
router.get('/satisfaction', asyncHandler(async (req, res) => {
  const { pageId } = req.query;
  
  const filter = { satisfactionRating: { $exists: true } };
  if (pageId) filter.pageId = pageId;
  
  const satisfaction = await Conversation.aggregate([
    { $match: filter },
    {
      $group: {
        _id: '$satisfactionRating',
        count: { $sum: 1 }
      }
    },
    { $sort: { _id: 1 } }
  ]);
  
  res.json({
    success: true,
    data: satisfaction
  });
}));

// Export des données
router.get('/export', asyncHandler(async (req, res) => {
  const { format = 'json', startDate, endDate, pageId } = req.query;
  
  const filter = {};
  if (startDate || endDate) {
    filter.createdAt = {};
    if (startDate) filter.createdAt.$gte = new Date(startDate);
    if (endDate) filter.createdAt.$lte = new Date(endDate);
  }
  if (pageId) filter.pageId = pageId;
  
  const conversations = await Conversation.find(filter)
    .populate('pageId', 'pageName')
    .sort({ createdAt: -1 });
  
  if (format === 'csv') {
    // Générer CSV
    const csv = conversations.map(conv => ({
      id: conv._id,
      pageId: conv.pageId?.pageId || conv.pageId,
      pageName: conv.pageId?.pageName || 'N/A',
      senderId: conv.senderId,
      status: conv.status,
      messagesCount: conv.messages.length,
      createdAt: conv.createdAt,
      lastActivity: conv.lastActivity,
      satisfactionRating: conv.satisfactionRating || 'N/A'
    }));
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=conversations.csv');
    
    // Convertir en CSV simple
    const headers = Object.keys(csv[0] || {}).join(',');
    const rows = csv.map(row => Object.values(row).join(','));
    res.send([headers, ...rows].join('\n'));
  } else {
    res.json({
      success: true,
      data: conversations
    });
  }
}));

export default router;