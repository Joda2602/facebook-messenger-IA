import winston from 'winston';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configuration des formats de log
const logFormat = winston.format.combine(
  winston.format.timestamp({
    format: 'YYYY-MM-DD HH:mm:ss'
  }),
  winston.format.errors({ stack: true }),
  winston.format.json(),
  winston.format.prettyPrint()
);

// Configuration du logger principal
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: logFormat,
  defaultMeta: { service: 'facebook-messenger-ai' },
  transports: [
    // Logs d'erreur dans un fichier séparé
    new winston.transports.File({
      filename: join(__dirname, '../logs/error.log'),
      level: 'error',
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
    
    // Tous les logs dans un fichier général
    new winston.transports.File({
      filename: join(__dirname, '../logs/combined.log'),
      maxsize: 5242880, // 5MB
      maxFiles: 10,
    }),
    
    // Logs spécifiques à Facebook
    new winston.transports.File({
      filename: join(__dirname, '../logs/facebook.log'),
      level: 'info',
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
    
    // Logs d'IA
    new winston.transports.File({
      filename: join(__dirname, '../logs/ai.log'),
      level: 'info',
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    })
  ],
});

// En développement, ajouter les logs dans la console
if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.combine(
      winston.format.colorize(),
      winston.format.simple(),
      winston.format.printf(({ timestamp, level, message, service, ...meta }) => {
        return `${timestamp} [${service}] ${level}: ${message} ${Object.keys(meta).length ? JSON.stringify(meta, null, 2) : ''}`;
      })
    )
  }));
}

// Logger spécialisé pour Facebook
export const facebookLogger = winston.createLogger({
  level: 'info',
  format: logFormat,
  defaultMeta: { service: 'facebook-webhook' },
  transports: [
    new winston.transports.File({
      filename: join(__dirname, '../logs/facebook.log'),
      maxsize: 5242880,
      maxFiles: 5,
    })
  ]
});

// Logger spécialisé pour l'IA
export const aiLogger = winston.createLogger({
  level: 'info',
  format: logFormat,
  defaultMeta: { service: 'ai-service' },
  transports: [
    new winston.transports.File({
      filename: join(__dirname, '../logs/ai.log'),
      maxsize: 5242880,
      maxFiles: 5,
    })
  ]
});

// Fonctions utilitaires pour le logging
export const logInfo = (message, meta = {}) => {
  logger.info(message, meta);
};

export const logError = (message, error = null, meta = {}) => {
  const errorMeta = error ? {
    error: {
      message: error.message,
      stack: error.stack,
      name: error.name
    },
    ...meta
  } : meta;
  
  logger.error(message, errorMeta);
};

export const logWarning = (message, meta = {}) => {
  logger.warn(message, meta);
};

export const logDebug = (message, meta = {}) => {
  logger.debug(message, meta);
};

// Fonction pour logger les requêtes HTTP
export const logRequest = (req, res, responseTime) => {
  const logData = {
    method: req.method,
    url: req.url,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    responseTime: `${responseTime}ms`,
    statusCode: res.statusCode,
    contentLength: res.get('Content-Length') || 0
  };
  
  if (res.statusCode >= 400) {
    logError('HTTP Request Error', null, logData);
  } else {
    logInfo('HTTP Request', logData);
  }
};

// Fonction pour logger les événements Facebook
export const logFacebookEvent = (eventType, data, meta = {}) => {
  facebookLogger.info(`Facebook Event: ${eventType}`, {
    eventType,
    data,
    ...meta
  });
};

// Fonction pour logger les interactions IA
export const logAIInteraction = (input, output, responseTime, meta = {}) => {
  aiLogger.info('AI Interaction', {
    input: input.substring(0, 200), // Limiter la taille du log
    output: output.substring(0, 200),
    responseTime: `${responseTime}ms`,
    inputLength: input.length,
    outputLength: output.length,
    ...meta
  });
};

export default logger;