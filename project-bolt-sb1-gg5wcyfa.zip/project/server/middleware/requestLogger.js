import { logRequest } from '../utils/logger.js';

// Middleware pour logger toutes les requêtes HTTP
export const requestLogger = (req, res, next) => {
  const startTime = Date.now();
  
  // Capturer la fin de la réponse
  const originalSend = res.send;
  res.send = function(data) {
    const responseTime = Date.now() - startTime;
    logRequest(req, res, responseTime);
    originalSend.call(this, data);
  };
  
  next();
};

// Middleware pour logger les requêtes spécifiques à Facebook
export const facebookRequestLogger = (req, res, next) => {
  const startTime = Date.now();
  
  // Log des détails spécifiques à Facebook
  if (req.method === 'POST' && req.body) {
    console.log('📨 Facebook Webhook Request:', {
      method: req.method,
      url: req.url,
      headers: {
        'x-hub-signature': req.get('x-hub-signature'),
        'x-hub-signature-256': req.get('x-hub-signature-256'),
        'content-type': req.get('content-type')
      },
      body: JSON.stringify(req.body, null, 2)
    });
  }
  
  const originalSend = res.send;
  res.send = function(data) {
    const responseTime = Date.now() - startTime;
    console.log('📤 Facebook Webhook Response:', {
      statusCode: res.statusCode,
      responseTime: `${responseTime}ms`,
      response: data
    });
    originalSend.call(this, data);
  };
  
  next();
};