import { logError } from '../utils/logger.js';

// Classe d'erreur personnalisée
export class AppError extends Error {
  constructor(message, statusCode = 500, isOperational = true) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    this.timestamp = new Date().toISOString();
    
    Error.captureStackTrace(this, this.constructor);
  }
}

// Middleware de gestion d'erreurs global
export const errorHandler = (err, req, res, next) => {
  let error = { ...err };
  error.message = err.message;

  // Log de l'erreur
  logError('Application Error', err, {
    url: req.url,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    body: req.body,
    params: req.params,
    query: req.query
  });

  // Erreur de validation Mongoose
  if (err.name === 'ValidationError') {
    const message = Object.values(err.errors).map(val => val.message).join(', ');
    error = new AppError(message, 400);
  }

  // Erreur de duplication MongoDB
  if (err.code === 11000) {
    const message = 'Ressource déjà existante';
    error = new AppError(message, 400);
  }

  // Erreur JWT
  if (err.name === 'JsonWebTokenError') {
    const message = 'Token invalide';
    error = new AppError(message, 401);
  }

  // Erreur JWT expiré
  if (err.name === 'TokenExpiredError') {
    const message = 'Token expiré';
    error = new AppError(message, 401);
  }

  // Erreur de cast MongoDB
  if (err.name === 'CastError') {
    const message = 'Ressource non trouvée';
    error = new AppError(message, 404);
  }

  // Erreur Axios (API externes)
  if (err.isAxiosError) {
    const message = err.response?.data?.message || 'Erreur API externe';
    const statusCode = err.response?.status || 500;
    error = new AppError(message, statusCode);
  }

  // Réponse d'erreur
  res.status(error.statusCode || 500).json({
    success: false,
    error: {
      message: error.message || 'Erreur serveur interne',
      ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
    },
    timestamp: error.timestamp || new Date().toISOString(),
    path: req.url,
    method: req.method
  });
};

// Middleware pour capturer les erreurs async
export const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Middleware pour les routes non trouvées
export const notFound = (req, res, next) => {
  const error = new AppError(`Route ${req.originalUrl} non trouvée`, 404);
  next(error);
};

// Gestionnaire d'erreurs non capturées
export const handleUncaughtException = () => {
  process.on('uncaughtException', (err) => {
    logError('Uncaught Exception', err);
    console.log('UNCAUGHT EXCEPTION! 💥 Shutting down...');
    process.exit(1);
  });
};

// Gestionnaire de promesses rejetées
export const handleUnhandledRejection = (server) => {
  process.on('unhandledRejection', (err) => {
    logError('Unhandled Rejection', err);
    console.log('UNHANDLED REJECTION! 💥 Shutting down...');
    server.close(() => {
      process.exit(1);
    });
  });
};