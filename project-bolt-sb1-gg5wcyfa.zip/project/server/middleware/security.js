import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { AppError } from './errorHandler.js';
import { logWarning } from '../utils/logger.js';

// Configuration du rate limiting
export const createRateLimit = (windowMs = 15 * 60 * 1000, max = 100, message = 'Trop de requêtes') => {
  return rateLimit({
    windowMs,
    max,
    message: {
      success: false,
      error: {
        message,
        retryAfter: Math.ceil(windowMs / 1000)
      }
    },
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
      logWarning('Rate limit exceeded', {
        ip: req.ip,
        url: req.url,
        userAgent: req.get('User-Agent')
      });
      
      res.status(429).json({
        success: false,
        error: {
          message,
          retryAfter: Math.ceil(windowMs / 1000)
        }
      });
    }
  });
};

// Rate limit général
export const generalRateLimit = createRateLimit(15 * 60 * 1000, 100, 'Trop de requêtes, réessayez dans 15 minutes');

// Rate limit pour les webhooks Facebook
export const webhookRateLimit = createRateLimit(1 * 60 * 1000, 60, 'Trop de webhooks, réessayez dans 1 minute');

// Rate limit pour l'API IA
export const aiRateLimit = createRateLimit(1 * 60 * 1000, 20, 'Trop de requêtes IA, réessayez dans 1 minute');

// Configuration de sécurité avec Helmet
export const securityHeaders = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'", "https://api.openai.com", "https://graph.facebook.com"]
    }
  },
  crossOriginEmbedderPolicy: false
});

// Validation des tokens Facebook
export const validateFacebookToken = (req, res, next) => {
  const verifyToken = process.env.FACEBOOK_VERIFY_TOKEN;
  
  if (req.method === 'GET') {
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];
    
    if (!mode || !token) {
      return next(new AppError('Paramètres de vérification manquants', 400));
    }
    
    if (mode !== 'subscribe' || token !== verifyToken) {
      return next(new AppError('Token de vérification invalide', 403));
    }
    
    return res.status(200).send(challenge);
  }
  
  next();
};

// Validation des signatures Facebook (pour POST)
export const validateFacebookSignature = (req, res, next) => {
  // En production, vous devriez valider la signature X-Hub-Signature-256
  // const signature = req.get('x-hub-signature-256');
  // const expectedSignature = crypto
  //   .createHmac('sha256', process.env.FACEBOOK_APP_SECRET)
  //   .update(JSON.stringify(req.body))
  //   .digest('hex');
  
  // Pour le moment, on passe à l'étape suivante
  next();
};

// Middleware de validation des données d'entrée
export const validateInput = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    if (error) {
      const message = error.details.map(detail => detail.message).join(', ');
      return next(new AppError(message, 400));
    }
    next();
  };
};