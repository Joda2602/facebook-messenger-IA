import axios from 'axios';
import FacebookPage from '../models/FacebookPage.js';
import { logInfo, logError, logFacebookEvent } from '../utils/logger.js';

class FacebookService {
  constructor() {
    this.pages = new Map();
    this.loadPages();
  }

  async loadPages() {
    try {
      const pages = await FacebookPage.find({ isActive: true });
      pages.forEach(page => {
        this.pages.set(page.pageId, page);
      });
      logInfo('Facebook pages loaded', { count: pages.length });
    } catch (error) {
      logError('Failed to load Facebook pages', error);
    }
  }

  async sendMessage(pageId, recipientId, message) {
    try {
      const page = this.pages.get(pageId);
      if (!page) {
        throw new Error(`Page ${pageId} not found or not active`);
      }

      const requestBody = {
        recipient: { id: recipientId },
        message: this.formatMessage(message)
      };

      const response = await axios.post(
        `https://graph.facebook.com/v18.0/me/messages?access_token=${page.accessToken}`,
        requestBody,
        { headers: { 'Content-Type': 'application/json' } }
      );

      logFacebookEvent('message_sent', {
        pageId,
        recipientId,
        messageType: typeof message === 'string' ? 'text' : 'structured'
      });

      return response.data;
    } catch (error) {
      logError('Failed to send Facebook message', error, { pageId, recipientId });
      throw error;
    }
  }

  formatMessage(message) {
    if (typeof message === 'string') {
      return { text: message };
    }

    const formatted = {};

    if (message.text) {
      formatted.text = message.text;
    }

    if (message.quickReplies && message.quickReplies.length > 0) {
      formatted.quick_replies = message.quickReplies.map(reply => ({
        content_type: 'text',
        title: reply,
        payload: reply.toUpperCase().replace(/\s+/g, '_')
      }));
    }

    if (message.attachments && message.attachments.length > 0) {
      formatted.attachment = {
        type: 'template',
        payload: {
          template_type: 'generic',
          elements: message.attachments.map(att => ({
            title: att.title,
            image_url: att.url,
            subtitle: att.description
          }))
        }
      };
    }

    return formatted;
  }

  async setPageSettings(pageId, settings) {
    try {
      const page = this.pages.get(pageId);
      if (!page) {
        throw new Error(`Page ${pageId} not found`);
      }

      // Configurer le message de bienvenue
      if (settings.greetingText) {
        await axios.post(
          `https://graph.facebook.com/v18.0/me/messenger_profile?access_token=${page.accessToken}`,
          {
            greeting: [{
              locale: 'default',
              text: settings.greetingText
            }]
          }
        );
      }

      // Configurer le bouton "Commencer"
      if (settings.getStartedPayload) {
        await axios.post(
          `https://graph.facebook.com/v18.0/me/messenger_profile?access_token=${page.accessToken}`,
          {
            get_started: {
              payload: settings.getStartedPayload
            }
          }
        );
      }

      // Configurer le menu persistant
      if (settings.persistentMenu && settings.persistentMenu.length > 0) {
        await axios.post(
          `https://graph.facebook.com/v18.0/me/messenger_profile?access_token=${page.accessToken}`,
          {
            persistent_menu: [{
              locale: 'default',
              composer_input_disabled: false,
              call_to_actions: settings.persistentMenu
            }]
          }
        );
      }

      logInfo('Facebook page settings updated', { pageId });
    } catch (error) {
      logError('Failed to update Facebook page settings', error, { pageId });
      throw error;
    }
  }

  async getPageInfo(pageId, accessToken) {
    try {
      const response = await axios.get(
        `https://graph.facebook.com/v18.0/${pageId}?fields=name,category,about&access_token=${accessToken}`
      );
      return response.data;
    } catch (error) {
      logError('Failed to get Facebook page info', error, { pageId });
      throw error;
    }
  }

  async verifyWebhook(pageId, verifyToken, challenge) {
    try {
      const page = this.pages.get(pageId);
      if (!page) {
        throw new Error(`Page ${pageId} not found`);
      }

      // Vérifier le token
      if (verifyToken !== process.env.FACEBOOK_VERIFY_TOKEN) {
        throw new Error('Invalid verify token');
      }

      // Marquer le webhook comme vérifié
      await FacebookPage.findOneAndUpdate(
        { pageId },
        { webhookVerified: true }
      );

      logInfo('Webhook verified', { pageId });
      return challenge;
    } catch (error) {
      logError('Webhook verification failed', error, { pageId });
      throw error;
    }
  }

  async addPage(pageData, userId) {
    try {
      // Vérifier que la page existe et que le token est valide
      const pageInfo = await this.getPageInfo(pageData.pageId, pageData.accessToken);
      
      const page = new FacebookPage({
        pageId: pageData.pageId,
        pageName: pageInfo.name,
        accessToken: pageData.accessToken,
        createdBy: userId,
        settings: pageData.settings || {}
      });

      await page.save();
      this.pages.set(page.pageId, page);

      // Configurer les paramètres de base
      await this.setPageSettings(page.pageId, page.settings);

      logInfo('Facebook page added', { pageId: page.pageId, pageName: page.pageName });
      return page;
    } catch (error) {
      logError('Failed to add Facebook page', error);
      throw error;
    }
  }

  async removePage(pageId) {
    try {
      await FacebookPage.findOneAndUpdate(
        { pageId },
        { isActive: false }
      );
      
      this.pages.delete(pageId);
      logInfo('Facebook page removed', { pageId });
    } catch (error) {
      logError('Failed to remove Facebook page', error, { pageId });
      throw error;
    }
  }

  getActivePagesCount() {
    return this.pages.size;
  }

  async reloadPages() {
    this.pages.clear();
    await this.loadPages();
  }
}

export default new FacebookService();