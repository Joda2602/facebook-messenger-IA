import Intent from '../models/Intent.js';
import Entity from '../models/Entity.js';
import { logInfo, logError } from '../utils/logger.js';

class NLPService {
  constructor() {
    this.intents = new Map();
    this.entities = new Map();
    this.loadModels();
  }

  async loadModels() {
    try {
      const intents = await Intent.find({ isActive: true }).sort({ priority: -1 });
      const entities = await Entity.find({ isActive: true });

      // Charger les intents en mémoire pour des performances optimales
      intents.forEach(intent => {
        this.intents.set(intent.name, intent);
      });

      // Charger les entités
      entities.forEach(entity => {
        this.entities.set(entity.name, entity);
      });

      logInfo('NLP models loaded', {
        intentsCount: intents.length,
        entitiesCount: entities.length
      });
    } catch (error) {
      logError('Failed to load NLP models', error);
    }
  }

  async processMessage(message, context = {}) {
    try {
      const normalizedMessage = message.toLowerCase().trim();
      
      // Extraction des entités
      const extractedEntities = await this.extractEntities(normalizedMessage);
      
      // Classification d'intention
      const intent = await this.classifyIntent(normalizedMessage, extractedEntities, context);
      
      // Génération de la réponse
      const response = await this.generateResponse(intent, extractedEntities, context);
      
      return {
        intent: intent?.name || 'unknown',
        confidence: intent?.confidence || 0,
        entities: extractedEntities,
        response,
        context: this.updateContext(context, intent, extractedEntities)
      };
    } catch (error) {
      logError('NLP processing error', error, { message });
      return {
        intent: 'error',
        confidence: 0,
        entities: [],
        response: "Désolé, je rencontre un problème technique. Un conseiller va vous contacter.",
        context
      };
    }
  }

  async extractEntities(message) {
    const entities = [];
    
    for (const [entityName, entityData] of this.entities) {
      if (entityData.entityType === 'regexp' && entityData.regexp) {
        const regex = new RegExp(entityData.regexp, 'gi');
        let match;
        while ((match = regex.exec(message)) !== null) {
          entities.push({
            entity: entityName,
            value: match[0],
            start: match.index,
            end: match.index + match[0].length
          });
        }
      } else if (entityData.entityType === 'custom') {
        entityData.values.forEach(valueData => {
          const allValues = [valueData.value, ...valueData.synonyms];
          allValues.forEach(value => {
            if (message.includes(value.toLowerCase())) {
              const start = message.indexOf(value.toLowerCase());
              entities.push({
                entity: entityName,
                value: valueData.value,
                start,
                end: start + value.length
              });
            }
          });
        });
      }
    }
    
    return entities;
  }

  async classifyIntent(message, entities, context) {
    let bestMatch = null;
    let bestScore = 0;

    for (const [intentName, intentData] of this.intents) {
      // Vérifier les contextes d'entrée
      if (intentData.contexts.input.length > 0) {
        const hasRequiredContext = intentData.contexts.input.some(ctx => 
          context.activeContexts && context.activeContexts.includes(ctx)
        );
        if (!hasRequiredContext) continue;
      }

      // Calculer le score de correspondance
      let score = 0;
      let matches = 0;

      intentData.trainingPhrases.forEach(phrase => {
        const similarity = this.calculateSimilarity(message, phrase.text.toLowerCase());
        if (similarity > score) {
          score = similarity;
        }
        if (similarity > 0.6) matches++;
      });

      // Bonus pour les entités correspondantes
      if (entities.length > 0) {
        intentData.trainingPhrases.forEach(phrase => {
          phrase.entities?.forEach(intentEntity => {
            const hasEntity = entities.some(e => e.entity === intentEntity.entity);
            if (hasEntity) score += 0.1;
          });
        });
      }

      // Bonus de priorité
      score += intentData.priority * 0.01;

      if (score > bestScore && score > 0.5) {
        bestScore = score;
        bestMatch = {
          ...intentData.toObject(),
          confidence: score
        };
      }
    }

    return bestMatch;
  }

  calculateSimilarity(str1, str2) {
    const words1 = str1.split(' ');
    const words2 = str2.split(' ');
    
    let matches = 0;
    words1.forEach(word1 => {
      if (words2.some(word2 => 
        word2.includes(word1) || word1.includes(word2) || 
        this.levenshteinDistance(word1, word2) <= 2
      )) {
        matches++;
      }
    });
    
    return matches / Math.max(words1.length, words2.length);
  }

  levenshteinDistance(str1, str2) {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }
    return matrix[str2.length][str1.length];
  }

  async generateResponse(intent, entities, context) {
    if (!intent || !intent.responses || intent.responses.length === 0) {
      return "Je ne suis pas sûr de comprendre. Pouvez-vous reformuler votre question ?";
    }

    // Sélectionner une réponse aléatoire
    const response = intent.responses[Math.floor(Math.random() * intent.responses.length)];
    
    // Remplacer les variables par les entités extraites
    let text = response.text;
    entities.forEach(entity => {
      text = text.replace(`{${entity.entity}}`, entity.value);
    });

    return text;
  }

  updateContext(currentContext, intent, entities) {
    const newContext = { ...currentContext };
    
    if (intent && intent.contexts.output.length > 0) {
      newContext.activeContexts = intent.contexts.output;
      newContext.contextLifespan = intent.contexts.lifespan;
    }
    
    // Décrémenter la durée de vie des contextes
    if (newContext.contextLifespan) {
      newContext.contextLifespan--;
      if (newContext.contextLifespan <= 0) {
        delete newContext.activeContexts;
        delete newContext.contextLifespan;
      }
    }
    
    return newContext;
  }

  async reloadModels() {
    this.intents.clear();
    this.entities.clear();
    await this.loadModels();
  }
}

export default new NLPService();