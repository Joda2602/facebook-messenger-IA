class ConversationService {
  constructor() {
    // En production, utilisez une vraie base de données
    this.conversations = new Map();
    this.messages = [];
  }

  async saveMessage({ senderId, message, sender, timestamp }) {
    const messageData = {
      id: Date.now() + Math.random(),
      senderId,
      message,
      sender,
      timestamp: timestamp || new Date()
    };

    this.messages.push(messageData);

    // Mettre à jour la conversation
    if (!this.conversations.has(senderId)) {
      this.conversations.set(senderId, {
        id: senderId,
        customer: `Client ${senderId.slice(-4)}`,
        messages: [],
        lastMessage: message,
        timestamp: this.formatTime(timestamp),
        status: 'active',
        unread: sender === 'user' ? 1 : 0
      });
    }

    const conversation = this.conversations.get(senderId);
    conversation.messages.push({
      id: messageData.id,
      sender: sender === 'user' ? 'customer' : 'bot',
      text: message,
      time: this.formatTime(timestamp)
    });
    
    conversation.lastMessage = message;
    conversation.timestamp = this.formatTime(timestamp);
    
    if (sender === 'user') {
      conversation.unread += 1;
      conversation.status = 'active';
    } else {
      conversation.status = 'resolved';
    }

    return messageData;
  }

  async getConversations() {
    return Array.from(this.conversations.values())
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  }

  async getConversation(senderId) {
    return this.conversations.get(senderId);
  }

  async markAsRead(senderId) {
    const conversation = this.conversations.get(senderId);
    if (conversation) {
      conversation.unread = 0;
    }
  }

  formatTime(timestamp) {
    const now = new Date();
    const messageTime = new Date(timestamp);
    const diffMinutes = Math.floor((now - messageTime) / (1000 * 60));

    if (diffMinutes < 1) return 'maintenant';
    if (diffMinutes < 60) return `${diffMinutes}min`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)}h`;
    return `${Math.floor(diffMinutes / 1440)}j`;
  }

  // Statistiques pour le dashboard
  getStats() {
    const totalMessages = this.messages.length;
    const activeConversations = Array.from(this.conversations.values())
      .filter(conv => conv.status === 'active').length;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayMessages = this.messages.filter(msg => 
      new Date(msg.timestamp) >= today
    ).length;

    return {
      totalMessages,
      todayMessages,
      activeConversations,
      averageResponseTime: '2.3s',
      satisfactionRate: '94%'
    };
  }
}

export default new ConversationService();