import axios from 'axios';

class AIService {
  constructor() {
    this.responses = new Map([
      ['bonjour', "Bonjour ! Je suis votre assistant virtuel. Comment puis-je vous aider aujourd'hui ?"],
      ['salut', "Salut ! Ravi de vous voir. Comment puis-je vous aider ?"],
      ['prix', "Je vais vous mettre en relation avec un conseiller commercial qui pourra vous donner tous les détails sur nos tarifs. Puis-je avoir votre nom et email ?"],
      ['tarif', "Nos tarifs varient selon vos besoins. Un conseiller va vous contacter pour vous proposer une offre personnalisée."],
      ['horaire', "Nous sommes ouverts du lundi au vendredi de 9h à 18h, et le samedi de 9h à 17h. Nous sommes fermés le dimanche."],
      ['ouvert', "Nous sommes actuellement ouverts ! Nos horaires sont du lundi au vendredi de 9h à 18h."],
      ['commande', "Pour passer une commande, je peux vous guider. De quel produit ou service avez-vous besoin ?"],
      ['livraison', "Nous proposons plusieurs options de livraison. Standard (2-3 jours) ou Express (24h). Souhaitez-vous plus d'informations ?"],
      ['support', "Je suis là pour vous aider ! Pouvez-vous me décrire votre problème plus précisément ?"],
      ['merci', "Je vous en prie ! N'hésitez pas si vous avez d'autres questions."],
      ['au revoir', "Au revoir ! Passez une excellente journée et n'hésitez pas à revenir si vous avez besoin d'aide."],
      ['bye', "À bientôt ! N'hésitez pas à me recontacter si vous avez des questions."]
    ]);
  }

  async generateResponse(message, senderId = null) {
    const normalizedMessage = message.toLowerCase().trim();
    
    // Recherche de mots-clés dans le message
    for (const [keyword, response] of this.responses) {
      if (normalizedMessage.includes(keyword)) {
        return response;
      }
    }
    
    // Si OpenAI est configuré, utiliser l'API
    if (process.env.OPENAI_API_KEY) {
      try {
        return await this.generateOpenAIResponse(message);
      } catch (error) {
        console.error('Erreur OpenAI:', error);
      }
    }
    
    // Réponse par défaut
    return "Je comprends votre demande. Laissez-moi vous mettre en relation avec un de nos conseillers qui pourra vous aider plus spécifiquement. Un membre de notre équipe vous contactera dans les plus brefs délais.";
  }

  async generateOpenAIResponse(message) {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: `Tu es un assistant virtuel professionnel et amical pour une entreprise. 
                     Réponds de manière concise et utile. Si tu ne peux pas aider directement, 
                     propose de mettre en relation avec un conseiller humain.
                     Réponds toujours en français.`
          },
          {
            role: 'user',
            content: message
          }
        ],
        max_tokens: 150,
        temperature: 0.7
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    return response.data.choices[0].message.content.trim();
  }

  // Ajouter une nouvelle réponse automatique
  addResponse(keyword, response) {
    this.responses.set(keyword.toLowerCase(), response);
  }

  // Supprimer une réponse automatique
  removeResponse(keyword) {
    this.responses.delete(keyword.toLowerCase());
  }

  // Obtenir toutes les réponses
  getAllResponses() {
    return Array.from(this.responses.entries()).map(([keyword, response]) => ({
      keyword,
      response
    }));
  }
}

export default new AIService();