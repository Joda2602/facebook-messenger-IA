import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { mkdirSync } from 'fs';

// Import de la configuration de base de données
import { connectDB } from './config/database.js';

// Import des middlewares et utilitaires
import { errorHandler, notFound, handleUncaughtException, handleUnhandledRejection } from './middleware/errorHandler.js';
import { requestLogger } from './middleware/requestLogger.js';
import { securityHeaders, generalRateLimit } from './middleware/security.js';
import logger, { logInfo, logError } from './utils/logger.js';

// Import des routes et services
import facebookRoutes from './routes/facebook.js';
import nlpRoutes from './routes/nlp.js';
import pagesRoutes from './routes/pages.js';
import analyticsRoutes from './routes/analytics.js';
import aiService from './services/aiService.js';
import nlpService from './services/nlpService.js';
import facebookService from './services/facebookService.js';

// Configuration
dotenv.config();
handleUncaughtException();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Créer le dossier logs s'il n'existe pas
try {
  mkdirSync(join(__dirname, 'logs'), { recursive: true });
} catch (error) {
  console.log('Dossier logs déjà existant ou erreur de création');
}

// Connexion à la base de données
connectDB();

// Middleware de sécurité
app.use(securityHeaders);
app.use(generalRateLimit);

// Middleware de base
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Middleware de logging
app.use(requestLogger);

// Serve static files from React build
app.use(express.static(join(__dirname, '../dist')));

// Routes
app.use('/webhook', facebookRoutes);
app.use('/api/nlp', nlpRoutes);
app.use('/api/pages', pagesRoutes);
app.use('/api/analytics', analyticsRoutes);

// Health check avec informations détaillées
app.get('/api/health', (req, res) => {
  const healthInfo = {
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    environment: process.env.NODE_ENV || 'development',
    version: process.env.npm_package_version || '1.0.0',
    services: {
      database: process.env.MONGODB_URI ? 'configured' : 'not configured',
      facebook: process.env.FACEBOOK_PAGE_ACCESS_TOKEN ? 'configured' : 'not configured',
      openai: process.env.OPENAI_API_KEY ? 'configured' : 'not configured',
      nlp: 'active',
      facebookService: `${facebookService.getActivePagesCount()} pages active`
    }
  };
  
  logInfo('Health check requested', { ip: req.ip });
  res.json(healthInfo);
});

// API endpoint pour tester l'IA avec NLP avancé
app.post('/api/ai/test', async (req, res, next) => {
  try {
    const { message, context } = req.body;
    
    if (!message || typeof message !== 'string') {
      return res.status(400).json({
        success: false,
        error: { message: 'Message requis et doit être une chaîne de caractères' }
      });
    }

    if (message.length > 1000) {
      return res.status(400).json({
        success: false,
        error: { message: 'Message trop long (maximum 1000 caractères)' }
      });
    }

    const startTime = Date.now();
    
    // Utiliser le service NLP avancé
    const nlpResult = await nlpService.processMessage(message, context || {});
    const responseTime = Date.now() - startTime;
    
    logInfo('AI test successful', {
      inputLength: message.length,
      intent: nlpResult.intent,
      confidence: nlpResult.confidence,
      responseTime: `${responseTime}ms`,
      ip: req.ip
    });
    
    res.json({
      success: true,
      data: {
        ...nlpResult,
        responseTime: `${responseTime}ms`
      }
    });
  } catch (error) {
    next(error);
  }
});

// API pour obtenir les statistiques système avancées
app.get('/api/stats', async (req, res) => {
  try {
    const stats = {
      system: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        cpu: process.cpuUsage(),
        platform: process.platform,
        nodeVersion: process.version
      },
      application: {
        environment: process.env.NODE_ENV || 'development',
        timestamp: new Date().toISOString(),
        activePagesCount: facebookService.getActivePagesCount()
      },
      database: {
        connected: true, // Sera mis à jour par le service de base de données
        collections: {
          conversations: 0,
          intents: 0,
          entities: 0,
          pages: 0
        }
      }
    };
    
    res.json(stats);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { message: 'Erreur lors de la récupération des statistiques' }
    });
  }
});

// Catch all handler pour React Router
app.get('*', (req, res) => {
  res.sendFile(join(__dirname, '../dist/index.html'));
});

// Middleware de gestion d'erreurs (doit être en dernier)
app.use(notFound);
app.use(errorHandler);

// Démarrage du serveur
const server = app.listen(PORT, () => {
  logInfo('Server started successfully', {
    port: PORT,
    environment: process.env.NODE_ENV || 'development',
    webhookUrl: process.env.WEBHOOK_URL || `http://localhost:${PORT}/webhook`,
    features: {
      nlp: 'enabled',
      multiPages: 'enabled',
      analytics: 'enabled',
      database: 'enabled'
    }
  });
  
  console.log(`🚀 Serveur démarré sur le port ${PORT}`);
  console.log(`📱 Webhook Facebook: ${process.env.WEBHOOK_URL || `http://localhost:${PORT}`}/webhook`);
  console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
  console.log(`📈 Stats: http://localhost:${PORT}/api/stats`);
  console.log(`🤖 NLP Service: Activé`);
  console.log(`📄 Multi-pages: Activé`);
  console.log(`📊 Analytics: Activé`);
});

// Gestion des arrêts gracieux
handleUnhandledRejection(server);

process.on('SIGTERM', () => {
  logInfo('SIGTERM received, shutting down gracefully');
  server.close(() => {
    logInfo('Process terminated');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logInfo('SIGINT received, shutting down gracefully');
  server.close(() => {
    logInfo('Process terminated');
    process.exit(0);
  });
});