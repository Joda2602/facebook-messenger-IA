import mongoose from 'mongoose';

const botConfigSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    default: 'Assistant virtuel'
  },
  personality: {
    type: String,
    enum: ['Amical et professionnel', 'Formel et concis', 'Décontracté et fun', 'Technique et précis'],
    default: 'Amical et professionnel'
  },
  systemPrompt: {
    type: String,
    default: `Tu es un assistant virtuel professionnel et amical pour une entreprise. 
             Réponds de manière concise et utile. Si tu ne peux pas aider directement, 
             propose de mettre en relation avec un conseiller humain.
             Réponds toujours en français et reste dans le contexte de l'entreprise.`
  },
  welcomeMessage: {
    type: String,
    default: "Bonjour ! Je suis votre assistant virtuel. Comment puis-je vous aider aujourd'hui ?"
  },
  fallbackMessage: {
    type: String,
    default: "Je ne suis pas sûr de comprendre votre demande. Pouvez-vous reformuler ou souhaitez-vous parler à un conseiller ?"
  },
  transferMessage: {
    type: String,
    default: "Je vais vous mettre en relation avec un de nos conseillers qui pourra vous aider plus spécifiquement."
  },
  faq: [{
    question: {
      type: String,
      required: true
    },
    answer: {
      type: String,
      required: true
    },
    keywords: [String],
    isActive: {
      type: Boolean,
      default: true
    }
  }],
  automatedResponses: [{
    trigger: {
      type: String,
      required: true
    },
    response: {
      type: String,
      required: true
    },
    isActive: {
      type: Boolean,
      default: true
    },
    priority: {
      type: Number,
      default: 0
    }
  }],
  settings: {
    autoResponse: {
      type: Boolean,
      default: true
    },
    transferToHuman: {
      type: Boolean,
      default: true
    },
    useOpenAI: {
      type: Boolean,
      default: false
    },
    responseDelay: {
      type: Number,
      default: 1000,
      min: 0,
      max: 10000
    },
    maxResponseLength: {
      type: Number,
      default: 500,
      min: 50,
      max: 2000
    },
    confidenceThreshold: {
      type: Number,
      default: 0.7,
      min: 0,
      max: 1
    }
  },
  businessHours: {
    enabled: {
      type: Boolean,
      default: false
    },
    timezone: {
      type: String,
      default: 'Europe/Paris'
    },
    schedule: {
      monday: { start: '09:00', end: '18:00', enabled: true },
      tuesday: { start: '09:00', end: '18:00', enabled: true },
      wednesday: { start: '09:00', end: '18:00', enabled: true },
      thursday: { start: '09:00', end: '18:00', enabled: true },
      friday: { start: '09:00', end: '18:00', enabled: true },
      saturday: { start: '09:00', end: '17:00', enabled: true },
      sunday: { start: '10:00', end: '16:00', enabled: false }
    },
    outsideHoursMessage: {
      type: String,
      default: "Nous sommes actuellement fermés. Nos horaires sont du lundi au vendredi de 9h à 18h. Laissez-nous votre message et nous vous répondrons dès que possible."
    }
  },
  analytics: {
    totalInteractions: { type: Number, default: 0 },
    successfulResponses: { type: Number, default: 0 },
    transferredToHuman: { type: Number, default: 0 },
    averageResponseTime: { type: Number, default: 0 },
    lastUpdated: { type: Date, default: Date.now }
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Index pour optimiser les requêtes
botConfigSchema.index({ createdBy: 1 });
botConfigSchema.index({ isActive: 1 });
botConfigSchema.index({ 'faq.keywords': 1 });

// Méthodes du modèle
botConfigSchema.methods.updateAnalytics = function(data) {
  this.analytics.totalInteractions += 1;
  if (data.successful) this.analytics.successfulResponses += 1;
  if (data.transferred) this.analytics.transferredToHuman += 1;
  if (data.responseTime) {
    this.analytics.averageResponseTime = 
      (this.analytics.averageResponseTime + data.responseTime) / 2;
  }
  this.analytics.lastUpdated = new Date();
  return this.save();
};

botConfigSchema.methods.isWithinBusinessHours = function() {
  if (!this.businessHours.enabled) return true;
  
  const now = new Date();
  const dayName = now.toLocaleLowerCase('en-US', { weekday: 'long' });
  const schedule = this.businessHours.schedule[dayName];
  
  if (!schedule || !schedule.enabled) return false;
  
  const currentTime = now.toLocaleTimeString('en-US', { 
    hour12: false, 
    hour: '2-digit', 
    minute: '2-digit' 
  });
  
  return currentTime >= schedule.start && currentTime <= schedule.end;
};

export default mongoose.model('BotConfig', botConfigSchema);