import mongoose from 'mongoose';

const facebookPageSchema = new mongoose.Schema({
  pageId: {
    type: String,
    required: true,
    unique: true
  },
  pageName: {
    type: String,
    required: true
  },
  accessToken: {
    type: String,
    required: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  webhookVerified: {
    type: Boolean,
    default: false
  },
  settings: {
    greetingText: {
      type: String,
      default: "Bonjour ! Je suis votre assistant virtuel."
    },
    persistentMenu: [{
      type: {
        type: String,
        enum: ['web_url', 'postback'],
        required: true
      },
      title: String,
      url: String,
      payload: String
    }],
    getStartedPayload: {
      type: String,
      default: 'GET_STARTED'
    }
  },
  analytics: {
    totalMessages: { type: Number, default: 0 },
    totalConversations: { type: Number, default: 0 },
    averageResponseTime: { type: Number, default: 0 },
    satisfactionRate: { type: Number, default: 0 }
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

// Index pour optimiser les requêtes
facebookPageSchema.index({ pageId: 1 });
facebookPageSchema.index({ createdBy: 1 });
facebookPageSchema.index({ isActive: 1 });

export default mongoose.model('FacebookPage', facebookPageSchema);