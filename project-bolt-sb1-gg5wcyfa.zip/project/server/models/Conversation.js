import mongoose from 'mongoose';

const conversationSchema = new mongoose.Schema({
  senderId: {
    type: String,
    required: true,
    index: true
  },
  pageId: {
    type: String,
    required: true,
    index: true
  },
  customerInfo: {
    name: String,
    email: String,
    phone: String,
    profilePic: String,
    locale: String,
    timezone: String
  },
  messages: [{
    messageId: String,
    text: String,
    sender: {
      type: String,
      enum: ['user', 'bot', 'human'],
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    intent: String,
    confidence: Number,
    entities: [{
      entity: String,
      value: String,
      start: Number,
      end: Number
    }],
    attachments: [{
      type: {
        type: String,
        enum: ['image', 'video', 'audio', 'file']
      },
      url: String,
      title: String
    }],
    quickReplies: [String],
    isRead: {
      type: Boolean,
      default: false
    }
  }],
  status: {
    type: String,
    enum: ['active', 'resolved', 'pending', 'transferred'],
    default: 'active'
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  tags: [String],
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  satisfactionRating: {
    type: Number,
    min: 1,
    max: 5
  },
  satisfactionComment: String,
  context: {
    currentIntent: String,
    activeContexts: [String],
    contextLifespan: Number,
    userPreferences: mongoose.Schema.Types.Mixed,
    sessionData: mongoose.Schema.Types.Mixed
  },
  analytics: {
    totalMessages: { type: Number, default: 0 },
    botMessages: { type: Number, default: 0 },
    humanMessages: { type: Number, default: 0 },
    averageResponseTime: { type: Number, default: 0 },
    firstResponseTime: Number,
    resolutionTime: Number,
    transferredAt: Date
  },
  lastActivity: {
    type: Date,
    default: Date.now
  },
  isArchived: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

// Index composés pour optimiser les requêtes
conversationSchema.index({ senderId: 1, pageId: 1 });
conversationSchema.index({ status: 1, lastActivity: -1 });
conversationSchema.index({ pageId: 1, status: 1 });
conversationSchema.index({ assignedTo: 1, status: 1 });
conversationSchema.index({ createdAt: -1 });

// Méthodes du modèle
conversationSchema.methods.addMessage = function(messageData) {
  this.messages.push(messageData);
  this.lastActivity = new Date();
  this.analytics.totalMessages += 1;
  
  if (messageData.sender === 'bot') {
    this.analytics.botMessages += 1;
  } else if (messageData.sender === 'human') {
    this.analytics.humanMessages += 1;
  }
  
  return this.save();
};

conversationSchema.methods.updateStatus = function(newStatus) {
  const oldStatus = this.status;
  this.status = newStatus;
  this.lastActivity = new Date();
  
  if (newStatus === 'transferred' && oldStatus !== 'transferred') {
    this.analytics.transferredAt = new Date();
  }
  
  if (newStatus === 'resolved' && this.createdAt) {
    this.analytics.resolutionTime = Date.now() - this.createdAt.getTime();
  }
  
  return this.save();
};

conversationSchema.methods.markAsRead = function() {
  this.messages.forEach(message => {
    if (message.sender === 'user') {
      message.isRead = true;
    }
  });
  return this.save();
};

conversationSchema.methods.getUnreadCount = function() {
  return this.messages.filter(msg => 
    msg.sender === 'user' && !msg.isRead
  ).length;
};

// Méthodes statiques
conversationSchema.statics.findByPageAndSender = function(pageId, senderId) {
  return this.findOne({ pageId, senderId, isArchived: false });
};

conversationSchema.statics.getActiveConversations = function(pageId) {
  return this.find({ 
    pageId, 
    status: { $in: ['active', 'pending'] },
    isArchived: false 
  }).sort({ lastActivity: -1 });
};

export default mongoose.model('Conversation', conversationSchema);