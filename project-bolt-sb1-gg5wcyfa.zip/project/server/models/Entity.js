import mongoose from 'mongoose';

const entitySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  displayName: {
    type: String,
    required: true
  },
  entityType: {
    type: String,
    enum: ['system', 'custom', 'regexp'],
    default: 'custom'
  },
  values: [{
    value: String,
    synonyms: [String]
  }],
  regexp: String,
  isActive: {
    type: Boolean,
    default: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

entitySchema.index({ name: 1 });
entitySchema.index({ entityType: 1 });

export default mongoose.model('Entity', entitySchema);