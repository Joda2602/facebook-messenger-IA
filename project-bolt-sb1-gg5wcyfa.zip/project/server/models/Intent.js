import mongoose from 'mongoose';

const intentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  displayName: {
    type: String,
    required: true
  },
  description: String,
  trainingPhrases: [{
    text: String,
    entities: [{
      entity: String,
      value: String,
      start: Number,
      end: Number
    }]
  }],
  responses: [{
    text: String,
    quickReplies: [String],
    attachments: [{
      type: {
        type: String,
        enum: ['image', 'video', 'audio', 'file']
      },
      url: String,
      title: String
    }]
  }],
  actions: [{
    type: {
      type: String,
      enum: ['webhook', 'transfer_to_human', 'set_context', 'api_call']
    },
    config: mongoose.Schema.Types.Mixed
  }],
  contexts: {
    input: [String],
    output: [String],
    lifespan: { type: Number, default: 5 }
  },
  fallbackIntent: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  priority: {
    type: Number,
    default: 0
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

// Index pour optimiser les requêtes NLP
intentSchema.index({ name: 1 });
intentSchema.index({ isActive: 1, priority: -1 });
intentSchema.index({ 'trainingPhrases.text': 'text' });

export default mongoose.model('Intent', intentSchema);